/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 * La clase ExcepcionEstructuraIncorrecta lanzará una excepción en el caso de
 * que la estructura de el contenido que se ha metido en el fichero no concuerda
 * con la manera en la que se deberían de recibir los datos de una poblacion.
 *
 * @author sanchavonknobloch
 */
public class ExcepcionEstructuraIncorrecta extends Exception {

    public ExcepcionEstructuraIncorrecta(String message) {
        super(message);
    }
}
