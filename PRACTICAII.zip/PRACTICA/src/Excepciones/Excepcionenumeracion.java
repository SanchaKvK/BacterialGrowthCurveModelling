/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 * La clase de excepcion de enumeracion comprueba que la enumeracion luminosidad
 * que se crea en la clase Poblacionbacteria toma un valor valido: Alta,Media o
 * Baja.
 *
 * @author sanchavonknobloch
 */
public class Excepcionenumeracion extends Exception {

    public Excepcionenumeracion(String message) {
        super(message);
    }
}
