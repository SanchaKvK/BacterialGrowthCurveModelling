/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 * La clase Excepcionfecha comprueba que un dia, mes y año estan en un rango
 * valido para poder crear una fecha para la poblacion de bacterias.
 *
 * @author sanchavonknobloch
 */
public class Excepcionfecha extends Exception {

    public Excepcionfecha(String message) {
        super(message);
    }
}
