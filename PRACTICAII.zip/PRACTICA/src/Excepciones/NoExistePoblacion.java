/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 * La clase NoExistePoblacion comprueba si la poblacion que se busca en un
 * experimento esta dentro, es decir, si (existe) es parte de ese experimento.
 *
 * @author sanchavonknobloch
 */
public class NoExistePoblacion extends Exception {

}
