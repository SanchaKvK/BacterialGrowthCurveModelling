package excepciones;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * La clase Excepcioncomida sirve para comprobar que el atributo de la clase
 * comida de tipo entero de comida(tanto inicial,en el ultimo dia de incremento
 * o final) se encuentren en el rango de 0-300000.
 *
 * @author sanchavonknobloch
 */
public class Excepcioncomida extends Exception {

    public Excepcioncomida(String message) {
        super(message);
    }
}
