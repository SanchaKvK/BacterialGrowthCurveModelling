/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 * La clase MismaPoblacionExcepcion gestiona la excepcion de que dado un
 * experimento, no se añade una poblacion de bacterias igual(segun los
 * requisitos establecidos del metodo equals de la clase bacteria) a una
 * previamente creada.
 *
 * @author sanchavonknobloch
 */
public class MismaPoblacionException extends Exception {

}
