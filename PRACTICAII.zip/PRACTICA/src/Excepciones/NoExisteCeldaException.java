/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 * Esta clase de tipo excepcion se utiliza en la clase Bacteria con el fin de
 * controlar el movimiento de bacterias a celdas contiguas. En el caso de que
 * una bacteria ya se encuentre en una de las celdas del borde del plato de
 * cultivo y tenga que moverse a una posicion que estaría fuera del plato, se
 * lanza una excepcion de este tipo.
 *
 * @author sanchavonknobloch
 */
public class NoExisteCeldaException extends Exception {
}
