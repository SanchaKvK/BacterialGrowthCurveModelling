/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 *Esta clase que hereda de excepcion es una excepcion creada para gestionar
 * los casos en los que se introduce un numero negativo de bacterias iniciales
 * Se lanza en el constructor de la clase Poblacionbacteria y debe ser gestionado
 * obligatoriamente.
 * @author sanchavonknobloch
 */
public class NumeroInicialBacteriasNoValidoException extends Exception{
    
}
