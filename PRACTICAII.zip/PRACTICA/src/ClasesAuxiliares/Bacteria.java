package ClasesAuxiliares;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import excepciones.NoExisteCeldaException;
import java.util.Random;

/**
 * La clase Bacteria representa una bacteria que formara parte de una poblacion
 * de bacterias dentro de un experimento. Consta de un atributo boolean que
 * representa si esta viva y dos atributos de tipo entero que en conjunto
 * representan la localización/ la celda en la que se encuentra la bacteria en
 * el plato de cultivo de la poblacion. tambien consta de tres metodos que,
 * representan celdas con tres tipos distintos de comida, y que llevan a la
 * bacteria a realizar distintas acciones.
 *
 * @author sanchavonknobloch
 */
public class Bacteria {

    private boolean vivo;
    private int localizacionfila;
    private int localizacioncolumna;

    /**
     *
     * @param i representa la fila de la celda
     * @param j representa la columna de la celda Por defecto al crear una
     * bacteria el atributo vivo toma el valor de verdadero.
     */
    public Bacteria(int i, int j) {
        this.localizacionfila = i;
        this.localizacioncolumna = j;
        this.vivo = true;
    }

    public int getFilai() {
        return localizacionfila;
    }

    public boolean getVivo() {
        return vivo;
    }

    public void setVivo(boolean estado) {
        vivo = estado;
    }

    public int getColumnaj() {
        return localizacioncolumna;
    }

    public void setFilai(int i) {
        localizacionfila = i;

    }

    public void setColumnaj(int j) {
        localizacioncolumna = j;
    }

    public void setCantidadComidaDiaria(int comida) {

    }

    /**
     * El metodo CeldaTipo1 sirve para establecer las acciones que debe tomar
     * una bacteria que se encuentre en una celda donde haya igual o mas de 100
     * microgramos de comida .
     *
     * @param i la fila en la que se encuentra la bacteria
     * @param j la columna en la cual se encuentra la bacteria
     * @throws NoExisteCeldaException en el caso de que la celda a la que se
     * deba mover la bacteria esté fuera del plato de cultivo
     */
    public void CeldaTipo1(int i, int j) throws NoExisteCeldaException {
        Random randomnumber = new Random();
        int valorandom = randomnumber.nextInt(100);
        if (valorandom < 3) {
            vivo = false;
        }
        if (valorandom >= 60 && valorandom < 100) {
            if (valorandom >= 60 && valorandom < 65) {
                if (i - 1 < 0 || j - 1 < 0) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i - 1;
                    localizacioncolumna = j - 1;
                }
            }
            if (valorandom >= 65 && valorandom < 70) {
                if (i - 1 < 0) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i - 1;
                }
            }
            if (valorandom >= 70 && valorandom < 75) {
                if (i - 1 < 0 || j + 1 > 20) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i - 1;
                    localizacioncolumna = j - 1;
                }
            }
            if (valorandom >= 75 & valorandom < 80) {
                if (j - 1 < 0) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacioncolumna = j - 1;
                }
            }
            if (valorandom >= 85 && valorandom < 90) {
                if (i + 1 > 20 || j - 1 < 0) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i + 1;
                    localizacioncolumna = j - 1;
                }
            }
            if (valorandom >= 80 && valorandom < 85) {
                if (j + 1 > 20) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacioncolumna = j + 1;
                }
            }
            if (valorandom >= 95 && valorandom < 100) {
                if (i + 1 > 20 || j + 1 > 20) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i + 1;
                    localizacioncolumna = j + 1;
                }
            }
            if (valorandom >= 90 && valorandom < 95) {
                if (i + 1 > 20) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i + 1;
                }
            }

        }
    }

    /**
     * El metodo CeldaTipo2 sirve para establecer las acciones que debe tomar
     * una bacteria que se encuentre en una celda donde haya mas de 9 y menos de
     * 100 microgramos de comida .
     *
     * @param i la fila en la que se encuentra la bacteria
     * @param j la columna en la cual se encuentra la bacteria
     * @throws NoExisteCeldaException en el caso de que la celda a la que se
     * deba mover la bacteria esté fuera del plato de cultivo
     */
    public void CeldaTipo2(int i, int j) throws NoExisteCeldaException {
        Random randomnumber = new Random();
        int valorandom = randomnumber.nextInt(100);
        if (valorandom < 6) {
            vivo = false;
        }
        if (valorandom >= 20 && valorandom < 30) {
            if (valorandom >= 60 && valorandom < 65) {
                if (i - 1 < 0 || j - 1 < 0) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i - 1;
                    localizacioncolumna = j - 1;
                }
            }
            if (valorandom >= 30 && valorandom < 40) {
                if (i - 1 < 0) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i - 1;
                }
            }
            if (valorandom >= 40 && valorandom < 50) {
                if (i - 1 < 0 || j + 1 > 20) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i - 1;
                    localizacioncolumna = j - 1;
                }
            }
            if (valorandom >= 50 & valorandom < 60) {
                if (j - 1 < 0) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacioncolumna = j - 1;
                }
            }
            if (valorandom >= 70 && valorandom < 80) {
                if (i + 1 > 20 || j - 1 < 0) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i + 1;
                    localizacioncolumna = j - 1;
                }
            }
            if (valorandom >= 60 && valorandom < 70) {
                if (j + 1 > 20) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacioncolumna = j + 1;
                }
            }
            if (valorandom >= 90 && valorandom < 100) {
                if (i + 1 > 20 || j + 1 > 20) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i + 1;
                    localizacioncolumna = j + 1;
                }
            }
            if (valorandom >= 80 && valorandom < 90) {
                if (i + 1 > 20) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i + 1;
                }

            }
        }
    }

    /**
     * El metodo CeldaTipo3 sirve para establecer las acciones que debe tomar
     * una bacteria que se encuentre en una celda donde haya 9 o menos
     * microgramos de comida .
     *
     * @param i la fila en la que se encuentra la bacteria
     * @param j la columna en la cual se encuentra la bacteria
     * @throws NoExisteCeldaException en el caso de que la celda a la que se
     * deba mover la bacteria esté fuera del plato de cultivo
     * @param i
     * @param j
     * @throws NoExisteCeldaException
     */
    public void CeldaTipo3(int i, int j) throws NoExisteCeldaException {
        Random randomnumber = new Random();
        int valorandom = randomnumber.nextInt(100);
        if (valorandom < 20) {
            vivo = false;
        }
        if (valorandom >= 60 && valorandom < 100) {
            if (valorandom >= 60 && valorandom < 65) {
                if (i - 1 < 0 || j - 1 < 0) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i - 1;
                    localizacioncolumna = j - 1;
                }
            }
            if (valorandom >= 65 && valorandom < 70) {
                if (i - 1 < 0) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i - 1;
                }
            }
            if (valorandom >= 70 && valorandom < 75) {
                if (i - 1 < 0 || j + 1 > 20) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i - 1;
                    localizacioncolumna = j - 1;
                }
            }
            if (valorandom >= 75 & valorandom < 80) {
                if (j - 1 < 0) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacioncolumna = j - 1;
                }
            }
            if (valorandom >= 85 && valorandom < 90) {
                if (i + 1 > 20 || j - 1 < 0) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i + 1;
                    localizacioncolumna = j - 1;
                }
            }
            if (valorandom >= 80 && valorandom < 85) {
                if (j + 1 > 20) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacioncolumna = j + 1;
                }
            }
            if (valorandom >= 95 && valorandom < 100) {
                if (i + 1 > 20 || j + 1 > 20) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i + 1;
                    localizacioncolumna = j + 1;
                }
            }
            if (valorandom >= 90 && valorandom < 95) {
                if (i + 1 > 20) {
                    throw new NoExisteCeldaException();
                } else {
                    localizacionfila = i + 1;
                }
            }

        }
    }

}
