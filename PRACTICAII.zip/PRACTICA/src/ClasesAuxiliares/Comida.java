/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesAuxiliares;

/**
 * La clase Comida sirve como una plantilla para el desarrollo de las cuatro
 * clases particulares de suministro de comida. Consta de 6 métodos y tres
 * atributos que tienen en comun las cuatro clases particulares de comida que
 * heredan de Comida.
 *
 * @author sanchavonknobloch
 */
public abstract class Comida {

    public Fecha fechainicio;
    public Fecha fechafin;
    public int comidainicio;

    /**
     * El metodo CantidadComidaDiaN sirve para generar la cantidad de comida que
     * se debe suministrar a la poblacion de bacterias en un dia entre la fecha
     * de comienzo de la poblacion y la final. Esta funcion será util en la
     * funcion de Montecarlo para luego realizar mas operaciones sobre la
     * cantidad de bacterias.
     *
     * @param dia : dia del que se quiere saber la cantidad de comida a
     * suministrar
     * @return devuelve la cantidad de comida a suministrar en int
     */
    public int CantidadComidaDiaN(int dia) {
        int cantidadcomida = 0;
        return cantidadcomida;
    }

    /**
     * El metodo CantidadComidaCadaDia sirve para generar la cantidad de comida
     * cada dia del experimento de una poblacion.
     *
     * @return un array de enteros con el valor de suministro de comida cada dia
     * de la duracion del experimento
     */
    public int[] CantidadComidaCadaDia() {
        int[] comidas = null;
        return comidas;
    }

    public String toFile() {
        String a = "";
        return a;
    }

    public Fecha getFechaInicio() {
        return fechainicio;
    }

    public Fecha getFechaFin() {
        return fechafin;
    }

    public int getComidaInicio() {
        return comidainicio;
    }
}
