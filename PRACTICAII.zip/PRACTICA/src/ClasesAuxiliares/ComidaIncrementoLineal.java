/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesAuxiliares;

import excepciones.Excepcioncomida;
import excepciones.Excepcionfecha;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * La clase ComidaIncrementoLineal que hereda de la clase Comida, representa un
 * tipo de suministro de comida en el que la cantidad de comida suministrada
 * durante la duracion de la poblacion incrementa desde la fecha de inicio hasta
 * la fecha final de forma lineal.
 *
 * @author sanchavonknobloch
 */
public class ComidaIncrementoLineal extends Comida {

    private int comidafin;

    /**
     *
     * @param fechainicio la fecha en la que comienza la poblacion
     * @param fechafin la fecha en la que termina la poblacion
     * @param cantidadcomidaprimerdia la cantidad de comida que se suministra a
     * la poblacion el primer dia del experimento
     * @param cantidadcomidaultimodia la cantidad de comida que se suministra a
     * la poblacion el ultimo dia del experimento
     * @throws Excepcioncomida si la cantidad de comida ingresada es mayor a
     * 300000microgramos o menor a 0
     */
    public ComidaIncrementoLineal(Fecha fechainicio, Fecha fechafin, int cantidadcomidaprimerdia, int cantidadcomidaultimodia) throws Excepcioncomida {

        if (cantidadcomidaprimerdia > 300000 || cantidadcomidaprimerdia < 1 || cantidadcomidaultimodia > 300000 || cantidadcomidaultimodia < 1) {
            throw new Excepcioncomida("rango");
        }
        this.fechainicio = fechainicio;
        this.fechafin = fechafin;
        this.comidainicio = cantidadcomidaprimerdia;
        this.comidafin = cantidadcomidaultimodia;
    }

    public int getComidainicial() {
        return this.comidainicio;
    }

    public int getComidaFin() {
        return this.comidafin;
    }

    @Override
    public Fecha getFechaInicio() {
        return this.fechainicio;
    }

    @Override
    public Fecha getFechaFin() {
        return this.fechafin;
    }

    @Override
    public int CantidadComidaDiaN(int dia) {
        int[] arraycomidas = CantidadComidaCadaDia();
        return arraycomidas[dia];
    }

    @Override
    public int[] CantidadComidaCadaDia() {
        LocalDate fechainicial = LocalDate.of(fechainicio.getAño(), fechainicio.getMes(), fechainicio.getDia());
        LocalDate fechafinal = LocalDate.of(fechafin.getAño(), fechafin.getMes(), fechafin.getDia());
        int numerodedias = (int) ChronoUnit.DAYS.between(fechainicial, fechafinal);
        int[] comidas = new int[numerodedias + 1];
        float dosisincremento = (float) (comidafin - comidainicio) / numerodedias;
        //con la dosis de incremento, hacemos un bucle que nos calcule la comida
        //para cada dia hasta el ultimo dia de incremento de comida. 
        //esto lo guardaremos en el array de tipo int que despues
        //devolveremos. 
        for (int i = 0; i <= numerodedias; i++) {
            int valorcomida = (int) (this.comidainicio + (i * dosisincremento));
            comidas[i] = valorcomida;
        }
        return comidas;
    }

    /**
     * El metodo toFile perimte imprimir el contenido de un objeto de tipo
     * comida con la estructura declarada: los enteros que representan
     * cantidades de comida, y las fechas, separadas entre barras.
     *
     * @return el string de los atributos de un objeto de tipo Comida separados
     * por comas.
     */
    @Override
    public String toFile() {
        return "ComidaIncrementoLineal" + "," + fechainicio.toFile() + "," + fechafin.toFile() + ","
                + comidainicio + "," + comidafin;
    }

    /**
     * El metodo toString perimte imprimir el contenido de un objeto de tipo
     * comida con la estructura declarada.
     *
     * @return el string que representa el objeto Comida.
     */
    @Override
    public String toString() {
        return "Fecha inicial:    " + fechainicio
                + "\nFecha final:    " + fechafin
                + "\nComida inicial:    " + comidainicio
                + "\nComida fin:    " + comidafin;
    }

    public static void main(String[] args) {
        Fecha fechainicio = null;
        Fecha fechafin = null;
        Fecha fecha3 = null;
        ComidaIncrementoLineal comida = null;
        try {
            fechainicio = new Fecha(10, 10, 2020);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(ComidaConstante.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            fechafin = new Fecha(12, 10, 2021);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(ComidaConstante.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            comida = new ComidaIncrementoLineal(fechainicio, fechafin, 300, 1805);
        } catch (Excepcioncomida ex) {
            Logger.getLogger(ComidaIncrementoLineal.class.getName()).log(Level.SEVERE, null, ex);
        }
        int[] cantidadcomida = comida.CantidadComidaCadaDia();
        for (int i = 0; i < cantidadcomida.length; i++) {
            System.out.println(cantidadcomida[i]);
        }
        System.out.println("EN el dia 3    " + comida.CantidadComidaDiaN(3));

    }

}
