/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesAuxiliares;

import excepciones.Excepcioncomida;
import excepciones.Excepcionfecha;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase ComidaConstante representa un tipo de suminstro de comida a una
 * poblacion de bacterias, donde cada día de los dias que dure la poblacion de
 * bacterias se les suministrará la misma cantidad de comida. El constructor de
 * la clase lanza una excepcion de tipo Excepcioncomida si el valor ingresado de
 * comida es mayor a 300000 o menor a 1.No añade ningun atributo mas, tiene los 
 * que hereda de la clase Comida. 
 *
 * @author sanchavonknobloch
 */
public class ComidaConstante extends Comida {
/**
 * @param cantidadcomidaprimerdia entero que representa la cantidad de comida a suministrar a las bacterias cada dia del experimento
 * @param fechainicio fecha de comienzo de la poblacion 
 * @param fechafin fecha de terminación de la poblacion
 * @throws Excepcioncomida en caso de que la cantidad de comida a suministrar ingresada sea mayor a 300000 o menor a 0.
 */
    public ComidaConstante(int cantidadcomidaprimerdia, Fecha fechainicio, Fecha fechafin) throws Excepcioncomida {
        if (cantidadcomidaprimerdia > 300000 || cantidadcomidaprimerdia < 1) {
            throw new Excepcioncomida("rango");
        }
        this.fechainicio = fechainicio;
        this.fechafin = fechafin;
        this.comidainicio = cantidadcomidaprimerdia;
    }

    @Override
    public int getComidaInicio() {
        return this.comidainicio;
    }

    @Override
    public Fecha getFechaInicio() {
        return this.fechainicio;
    }

    @Override
    public Fecha getFechaFin() {
        return this.fechafin;
    }

    @Override
    public int CantidadComidaDiaN(int dia) {
        return comidainicio;
    }

    @Override
    public int[] CantidadComidaCadaDia() {
        int[] comida = new int[1];
        comida[0] = comidainicio;
        return comida;
    }

    /**
     * El metodo toFile servirá posteriormente para guardar poblaciones de
     * bacterias en un fichero, y para su posterior recuperación.
     *
     * @return el string de los atributos de un objeto de tipo Comida separados
     * por comas.
     */
    @Override
    public String toFile() {
        return "ComidaConstante" + "," + fechainicio.toFile() + "," + fechafin.toFile() + "," + comidainicio;
    }

    @Override
    public String toString() {
        return "Fecha inicial:    " + fechainicio
                + "\nFecha final:    " + fechafin
                + "\nComida inicial:    " + comidainicio;
    }

    public static void main(String[] args) {
        Fecha fechainicio = null;
        Fecha fechafin = null;
        Fecha fecha3 = null;
        Comida c1 = null;
        try {
            fechainicio = new Fecha(10, 10, 2020);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(ComidaConstante.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            fechafin = new Fecha(15, 10, 2020);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(ComidaConstante.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            c1 = new ComidaConstante(30000, fechainicio, fechafin);
        } catch (Excepcioncomida ex) {
            System.out.println("la comida debe estar entre 1 y 300000");
        }
        try {
            fecha3 = new Fecha(15, 10, 2020);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(ComidaConstante.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(c1.CantidadComidaDiaN(3));

        int[] array = c1.CantidadComidaCadaDia();
        System.out.println(array[0]);
        System.out.println(c1);
        System.out.println(c1.toFile());
    }

}
