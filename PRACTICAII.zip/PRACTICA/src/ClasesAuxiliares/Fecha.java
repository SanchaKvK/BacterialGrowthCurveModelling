/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesAuxiliares;

import excepciones.Excepcionfecha;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * La clase fecha será instanciada mas adelante en la clase comida, y al ser la
 * clase comida instanciada dentro de poblacionbacteria también pertenecerá a
 * esa clase.Contiene tres atributos de tipo entero que representan el dia, el
 * mes y el año, es decir, instanciando esta clase creamos un objeto que es una
 * fecha.
 *
 * @author sanchavonknobloch
 */
public class Fecha {

    private final int dia;
    private final int mes;
    private final int año;

    public Fecha(int dia, int mes, int año) throws Excepcionfecha {

        if (dia > 31 || dia < 1) {
            throw new Excepcionfecha("dia");
        }
        if (mes > 12 || mes < 1) {
            throw new Excepcionfecha("mes");
        }
        //NO PONGO LIMITE SUPERIOR PORQUE PODEMOS ESTAR SIMULANDO UN EXPERIMENTO QUE VAMOS A
        //HACER EN EL FUTURO
        if (año < 2020) {
            throw new Excepcionfecha("año");
        }
        if ((mes == 2 || mes == 4 || mes == 6 || mes == 9 || mes == 11) && dia == 31) {
            throw new Excepcionfecha("combinacion");
        }
        if (mes == 2 && dia > 28) {
            throw new Excepcionfecha("combinacion");
        }
        this.dia = dia;
        this.mes = mes;
        this.año = año;

    }

    public int getDia() {
        return dia;
    }

    public int getMes() {
        return mes;
    }

    public int getAño() {
        return año;
    }

    /**
     * El metodo comprobarRango comprueba si la fecha que se le pasa como
     * argumento es posterior a la fecha desde la que se llama a la funcion. De
     * ser este el caso, la función devolvera true, en caso contrario false,
     *
     * @param fechamayor: representa la supuesta fecha posterior (puede
     * representar la fecha en la que termina el experimento o la ultima fecha
     * de incremento)
     */
    public Boolean anteriorA(Fecha mayor) {
        Boolean rango = false;
        if (this.año < mayor.año) {
            rango = true;
            return rango;
        }
        if (this.año > mayor.año) {
            return false;

        }
        if (this.año == mayor.año) {
            if (this.mes > mayor.mes) {
                return false;
            }
            if (this.mes == mayor.mes) {
                if (this.dia > mayor.dia) {
                    return false;
                }
                if (this.dia < mayor.dia) {
                    rango = true;
                    return rango;
                }
                if (this.dia == mayor.dia) {
                    return false;
                }

            }
        }
        return rango;
    }

    /**
     * El metodo toString perimte imprimir el contenido de un objeto de tipo
     * fecha con la estructura declarada: los enteros que representan el dia,mes
     * y año, separados entre barras.
     *
     * @return el string que representa el objeto fecha.
     */
    @Override
    public String toString() {
        return dia + "/" + mes + "/" + año;
    }

    /**
     * El metodo toFile permite crear un string con una estructura que será util
     * a la hora de escribir los objetos de tipo poblacion de bacteria en un
     * fichero asi como a la hora de leerlos.
     *
     * @return un string de los atributos de un objeto de tipo fecha separados
     * por comas.
     */
    public String toFile() {
        return dia + "," + mes + "," + año;
    }

    /*Crearemos ahora un main en el que se probarán tanto los metodos de la clase fecha
    (que no sean getters o setters):
 comprobarRango y fechaFinal, creando primero una instancia de la clase con el constructor
 e imprimiendo finalmente los contenidos por pantalla, con la funcion toString. 
     */
//MAIN DE PRUEBA
    public static void main(String[] args) {
        Fecha fecha1;
        Fecha fecha2;
        Fecha fecha3;
        Fecha fecha4;

        try {
            System.out.println("Deberia de haber 5 pruebas correctas");
            //comprobamos el año
            fecha1 = new Fecha(1, 10, 2000);
        } catch (Excepcionfecha a) {
            if (a.getMessage().equals("año")) {
                System.out.println("PRUEBA CORRECTA AÑO");
            }
        }
        //comprobamos el mes
        try {
            fecha2 = new Fecha(1, 15, 2020);
        } catch (Excepcionfecha b) {
            if (b.getMessage().equals("mes")) {
                System.out.println("PRUEBA CORRECTA MES");
            }
        }
        //comprobamos la combinacion dia-mes
        try {
            fecha3 = new Fecha(31, 2, 2020);
        } catch (Excepcionfecha c) {
            if (c.getMessage().equals("combinacion")) {
                System.out.println("PRUEBA CORRECTA COMBINACION MES-DIA");
            }
        }
        //comprobamos el dia
        try {
            fecha4 = new Fecha(35, 2, 2020);
        } catch (Excepcionfecha d) {
            if (d.getMessage().equals("dia")) {
                System.out.println("PRUEBA CORRECTA");
            }
        }
        //COMPROBAMOS FUNCIONES
        Fecha fecha5 = null;
        try {
            fecha5 = new Fecha(1, 10, 2020);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(Fecha.class.getName()).log(Level.SEVERE, null, ex);
        }
        Fecha fecha6 = null;
        try {
            fecha6 = new Fecha(5, 10, 2020);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(Fecha.class.getName()).log(Level.SEVERE, null, ex);
        }

        boolean fechaesposterior = true;
        if (fechaesposterior == fecha6.anteriorA(fecha5)) {
            System.out.println("la fecha es posterior");
        }

        System.out.println("la fecha es anterior");
    }
}
