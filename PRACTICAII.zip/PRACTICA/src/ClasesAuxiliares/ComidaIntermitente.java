/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesAuxiliares;

import excepciones.Excepcioncomida;
import excepciones.Excepcionfecha;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * La clase ComidaIntermitente que hereda de la clase Comida representa un tipo
 * de suministro de comida en el que in dia se suministra una cantidad de comida
 * constante y al siguiente no se proporciona comida.
 *
 * @author sanchavonknobloch
 */
public class ComidaIntermitente extends Comida {

    /**
     *
     * @param fechainicio fecha en la que comienza la poblacion de bacterias/
     * fecha de inicio de suministro de comida
     * @param fechafin fecha en la que termina la poblacion de bacterias/ fecha
     * fin de suministro de comida
     * @param cantidadcomidaprimerdia la cantidad que se les dará a las
     * bacterias los dias que reciban comida
     * @throws Excepcioncomida
     */
    public ComidaIntermitente(Fecha fechainicio, Fecha fechafin, int cantidadcomidaprimerdia) throws Excepcioncomida {
        if (cantidadcomidaprimerdia > 300000 || cantidadcomidaprimerdia < 1) {
            throw new Excepcioncomida("rango");
        }
        this.fechainicio = fechainicio;
        this.fechafin = fechafin;
        this.comidainicio = cantidadcomidaprimerdia;

    }

    public int getComidainicial() {
        return this.comidainicio;
    }

    @Override
    public Fecha getFechaInicio() {
        return this.fechainicio;
    }

    @Override
    public Fecha getFechaFin() {
        return this.fechafin;
    }

    @Override
    public int CantidadComidaDiaN(int dia) {
        int[] arraycomidas = CantidadComidaCadaDia();
        return arraycomidas[dia];
    }

    @Override
    public int[] CantidadComidaCadaDia() {
        LocalDate fechainicial = LocalDate.of(fechainicio.getAño(), fechainicio.getMes(), fechainicio.getDia());
        LocalDate fechafinal = LocalDate.of(fechafin.getAño(), fechafin.getMes(), fechafin.getDia());
        int numerodedias = (int) ChronoUnit.DAYS.between(fechainicial, fechafinal);
        System.out.println("El numero de dias es" + numerodedias);
        int[] comidas = new int[numerodedias + 1];
        comidas[0] = comidainicio;
        for (int i = 1; i < comidas.length; i++) {
            if (i % 2 == 0) {
                comidas[i] = comidainicio;
            } else {
                comidas[i] = 0;
            }
        }
        return comidas;
    }

    /**
     * El metodo toFile perimte imprimir el contenido de un objeto de tipo
     * comida con la estructura declarada: los enteros que representan
     * cantidades de comida, y las fechas, separadas entre barras.
     *
     * @return el string de los atributos de un objeto de tipo Comida separados
     * por comas.
     */
    @Override
    public String toFile() {
        return "ComidaIntermitente" + "," + fechainicio.toFile() + "," + fechafin.toFile() + ","
                + comidainicio;
    }

    /**
     * El metodo toString perimte imprimir el contenido de un objeto de tipo
     * comida con la estructura declarada.
     *
     * @return el string que representa el objeto Comida.
     */
    @Override
    public String toString() {
        return "Fecha inicial:    " + fechainicio
                + "\nFecha final:    " + fechafin
                + "\nComida inicial:    " + comidainicio;
    }

    public static void main(String[] args) {
        Fecha fechainicio = null;
        Fecha fechafin = null;
        Fecha fecha3 = null;
        Comida c1 = null;
        try {
            fechainicio = new Fecha(10, 10, 2020);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(ComidaConstante.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            fechafin = new Fecha(15, 10, 2020);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(ComidaConstante.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            c1 = new ComidaIntermitente(fechainicio, fechafin, 300);
        } catch (Excepcioncomida ex) {
            System.out.println("la comida debe estar entre 1 y 300000");
        }
        try {
            fecha3 = new Fecha(15, 10, 2020);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(ComidaConstante.class.getName()).log(Level.SEVERE, null, ex);
        }

        System.out.println("El dia 3 hay que dar" + c1.CantidadComidaDiaN(3) + "comida");

        int[] array = c1.CantidadComidaCadaDia();
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }
        System.out.println(c1.toFile());
    }
}
