/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesAuxiliares;

import excepciones.Excepcioncomida;
import excepciones.Excepcionfecha;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * La clase ComidaIncrementoDecremento que hereda de la clase Comida,representa un tipo de suminsitro de comida
 * en la que la cantidad de comida que se va suministrando durante la duración del
 * experimento crece hasta un dia, y comienza a decrecer desde entonces hasta la
 * fecha de finalización del experimento. 
 * @author sanchavonknobloch
 */
public class ComidaIncrementoDecremento extends Comida {

    private int comidapico; //comida en el ultimo dia de incremento de comida
    private int comidafin;
    private Fecha fechapico; //fecha del ultimo dia de incremento de comida
    /**
     *
     * @param fechainicio (objeto de tipo fecha) que describe el dia que empieza
     * la poblacion
     * @param fechapico (objeto de tipo fecha) que describe ultimo dia en el que
     * se incrementa la dosis de comida de la poblacion
     * @param fechafin (objeto de tipo fecha) que describe el dia en el que
     * termina la poblacion
     * @param comidainicio entero que describe la comida que se le da a las
     * bacterias el primer dia
     * @param comidapico entero que describe la comida que se le da a las
     * bacterias el ultimo dia en el que se incrementa la dosis de comida de la
     * poblaicon
     * @param comidafin entero que describe la comida que se le da a las
     * bacterias el ultimo dia
     */
    public ComidaIncrementoDecremento(Fecha fechainicio, Fecha fechapico, Fecha fechafin, int comidainicio, int comidapico, int comidafin) throws Excepcioncomida {
        if (comidainicio < 0 || comidainicio > 300000) {
            throw new Excepcioncomida("rango");
        }
        this.fechainicio = fechainicio;
        this.fechapico = fechapico;
        this.fechafin = fechafin;
        this.comidainicio = comidainicio;
        this.comidapico = comidapico;
        this.comidafin = comidafin;
    }

    @Override
    public int getComidaInicio() {
        return this.comidainicio;
    }

    public int getComidaFin() {
        return this.comidafin;
    }

    public int getComidaPico() {
        return this.comidapico;
    }

    @Override
    public Fecha getFechaInicio() {
        return this.fechainicio;
    }

    @Override
    public Fecha getFechaFin() {
        return this.fechafin;
    }

    public Fecha getFechaPico() {
        return this.fechapico;
    }

    @Override
    public int CantidadComidaDiaN(int dia) {
        int[] arraycomidas = CantidadComidaCadaDia();
        return arraycomidas[dia];
    }

    @Override
    public int[] CantidadComidaCadaDia() {
        LocalDate fechainicial = LocalDate.of(fechainicio.getAño(), fechainicio.getMes(), fechainicio.getDia());
        LocalDate fechadepico = LocalDate.of(fechapico.getAño(), fechapico.getMes(), fechapico.getDia());
        LocalDate fechafinal = LocalDate.of(fechafin.getAño(), fechafin.getMes(), fechafin.getDia());
        int numerodias = (int) ChronoUnit.DAYS.between(fechainicial, fechafinal);
        int[] comidastotal = new int[numerodias + 1];
        int numerodiasincremento = (int) ChronoUnit.DAYS.between(fechainicial, fechadepico);
        float dosisincremento = (float) (comidapico - comidainicio) / numerodiasincremento;
        for (int i = 0; i <= numerodiasincremento; i++) {
            int valorcomida = (int) (this.comidainicio + (i * dosisincremento));
            comidastotal[i] = valorcomida;
        }

        int numerodiasdecremento = (int) ChronoUnit.DAYS.between(fechadepico, fechafinal);
        float dosisdecremento = (float) (comidafin - comidapico) / (numerodiasdecremento);
        //creamos otro bucle for para rellenar los dias desde el dia siguiente
        //al ultimo dia de incremento de la comida hasta el dia final
        for (int i = numerodiasincremento + 1, j = 1; i < comidastotal.length; i++, j++) {
            comidastotal[i] = (int) (this.comidapico + (j * dosisdecremento));
        }

        return comidastotal;
    }

    /**
     * El metodo toFile perimte imprimir el contenido de un objeto de tipo
     * comida con la estructura declarada: los enteros que representan
     * cantidades de comida, y las fechas, separadas entre barras.
     *
     * @return el string de los atributos de un objeto de tipo Comida separados
     * por comas.//aunque es innecesario separar los dos strings por comas,
     * queda mas claro
     */
    @Override
    public String toFile() {
        return "ComidaIncrementoDecremento" + "," + fechainicio.toFile() + "," + fechapico.toFile() + "," + fechafin.toFile() + ","
                + comidainicio + "," + comidapico + "," + comidafin;
    }

    /**
     * El metodo toString perimte imprimir el contenido de un objeto de tipo
     * comida con la estructura declarada.
     *
     * @return el string que representa el objeto Comida.
     */
    @Override
    public String toString() {
        return "Fecha inicial:    " + fechainicio
                + " \nFecha pico:    " + fechapico
                + "\nFecha final:    " + fechafin
                + "\nComida inicial:    " + comidainicio
                + "\nComida pico:    " + comidapico
                + "\nComida fin:    " + comidafin;
    }

    /*Crearemos ahora un main en el que se probarán tanto los metodos de la clase Comida(que no sean getters o setters):
 calcularComida, creando primero una instancia de la clase con el constructor
 e imprimiendo finalmente los contenidos por pantalla. Tambien se imprimirá el objeto comida con el metodo toString. 
     */
//MAIN DE PRUEBA
    public static void main(String[] args) throws Excepcioncomida {
        Fecha fechainicio = null;
        Fecha fechapico = null;
        Fecha fechafin = null;
        Fecha fecha3 = null;
        ComidaIncrementoDecremento comida = null;
        try {
            fechainicio = new Fecha(10, 10, 2020);
        } catch (Excepcionfecha ex) {

        }
        try {
            fechapico = new Fecha(19, 10, 2020);
        } catch (Excepcionfecha ex) {

        }
        try {
            fechafin = new Fecha(20, 10, 2020);
        } catch (Excepcionfecha ex) {

        }
        try {
            comida = new ComidaIncrementoDecremento(fechainicio, fechapico, fechafin, 300, 1300, 400);
        } catch (Excepcioncomida ex) {
            System.out.println("ERROR EN RANGO COMIDA");
        }

        int[] array = comida.CantidadComidaCadaDia();
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }
        System.out.println("En el dia 7" + comida.CantidadComidaDiaN(7));
        System.out.println("En el dia 13 (no existe)" + comida.CantidadComidaDiaN(13));

    }
}
