/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica;

import ClasesAuxiliares.Comida;
import ClasesAuxiliares.Comida;
import ClasesAuxiliares.ComidaConstante;
import ClasesAuxiliares.ComidaConstante;
import ClasesAuxiliares.Fecha;
import ClasesAuxiliares.Fecha;
import excepciones.Excepcioncomida;
import excepciones.Excepcionfecha;
import excepciones.NumeroInicialBacteriasNoValidoException;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import practica.Poblacionbacteria;
import practica.Poblacionbacteria.luminosidad;

/**
 * La clase Ordenacion es una clase de funciones auxiliares que permiten ordenar
 * las poblaciones de bacterias de un experimento en base a distintos factores :
 * por orden alfabetico (OrdenacionPorNombre) por orden de cantidad de bacterias
 * iniciales (OrdenacionPorBacteriasIniciales) y ordenacion por la fecha inicial
 * de cada poblacion desde la mas antigua hasta la mas nueva.
 *
 * @author sanchavonknobloch
 */
public class AlgoritmosOrdenacion {

    /**
     * La funcion OrdenacionPorNombre ordena un LinkedList de poblaciones de
     * bacterias por orden alfabetico segun el nombre de cada poblacion.
     *
     * @param poblacion El linkedList con las poblaciones a ordenar.
     */
    public static void OrdenacionPorNombre(LinkedList<Poblacionbacteria> poblacion) {
        int tamaño = poblacion.size();
        Poblacionbacteria auxiliar;
        int ordenado;
        for (int posicionactual = 0; posicionactual < tamaño - 1; posicionactual++) {
            ordenado = 0;
            for (int posicioncomparacion = 0; posicioncomparacion < (tamaño - 1 - posicionactual); posicioncomparacion++) {
                if ((poblacion.get(posicioncomparacion).getNombre()).compareToIgnoreCase(poblacion.get(posicioncomparacion + 1).getNombre()) > 0) {
                    auxiliar = poblacion.get(posicioncomparacion + 1);
                    poblacion.set((posicioncomparacion + 1), poblacion.get(posicioncomparacion));
                    poblacion.set((posicioncomparacion), auxiliar);
                    ordenado = 1;
                }
            }
            if (ordenado == 0) {
                break;
            }
        }
    }

    /**
     * La función OrdenacionPorBaceriasIniciales ordena un LinkedList de
     * poblaciones de bacterias por orden de bacteriasiniciales de cada
     * poblacion.
     *
     * @param poblacion El linkedList con las poblaciones a ordenar. 
     */
    public static void OrdenacionPorBacteriasIniciales(LinkedList<Poblacionbacteria> poblacion) {
        int tamaño = poblacion.size();
        Poblacionbacteria auxiliar;
        int ordenado;
        for (int posicionactual = 0; posicionactual < tamaño - 1; posicionactual++) {
            ordenado = 0;
            for (int posicioncomparacion = 0; posicioncomparacion < (tamaño - 1 - posicionactual); posicioncomparacion++) {
                if (poblacion.get(posicioncomparacion).getNumeroBacteriasInicial() > (poblacion.get(posicioncomparacion + 1).getNumeroBacteriasInicial())) {
                    auxiliar = poblacion.get(posicioncomparacion + 1);
                    poblacion.set((posicioncomparacion + 1), poblacion.get(posicioncomparacion));
                    poblacion.set((posicioncomparacion), auxiliar);
                    ordenado = 1;
                }
            }
            if (ordenado == 0) {
                break;
            }
        }
    }

    /**
     * La función OrdenacionPorFecha ordena un LinkedList de poblaciones de
     * bacterias por orden de fecha de comienzo de la población, desde la
     * poblacion con la fecha de inicio mas antigua hasta la poblacion con la
     * fecha de inicio mas reciente.
     *
     * @param poblacion El linkedlist con poblaciones a ordenar. 
     */
    public static void OrdenacionPorFecha(LinkedList<Poblacionbacteria> poblacion) {
        int tamaño = poblacion.size();
        Poblacionbacteria auxiliar;
        int ordenado;
        for (int posicionactual = 0; posicionactual < tamaño - 1; posicionactual++) {
            ordenado = 0;
            for (int posicioncomparacion = 0; posicioncomparacion < (tamaño - 1 - posicionactual); posicioncomparacion++) {
                if (poblacion.get(posicioncomparacion).getComida().getFechaInicio().anteriorA(poblacion.get(posicioncomparacion + 1).getComida().getFechaInicio()) == false) {
                    auxiliar = poblacion.get(posicioncomparacion + 1);
                    poblacion.set((posicioncomparacion + 1), poblacion.get(posicioncomparacion));
                    poblacion.set((posicioncomparacion), auxiliar);
                    ordenado = 1;
                }
            }
            if (ordenado == 0) {
                break;
            }
        }

    }

    public static void main(String[] args) {
        //Hacer tres poblaciones
        //Hacemos un linkedlist con ellas
        //imprimimos el linkedlist
        Fecha fecha1 = null;
        Fecha fecha2 = null;
        Fecha fecha3 = null;
        luminosidad luz = luminosidad.Alta;
        try {
            fecha1 = new Fecha(10, 10, 2020);
            fecha2 = new Fecha(12, 10, 2020);
            fecha3 = new Fecha(18, 1, 2021);
        } catch (Excepcionfecha ex) {

        }
        //fecha fin
        Fecha ultima = null;
        try {
            ultima = new Fecha(10, 12, 2022);
        } catch (Excepcionfecha ex) {
        }
        Comida comida1 = null;
        Comida comida2 = null;
        Comida comida3 = null;
        //Comida 1 
        try {
            comida1 = new ComidaConstante(100, fecha1, ultima);
        } catch (Excepcioncomida ex) {
            Logger.getLogger(AlgoritmosOrdenacion.class.getName()).log(Level.SEVERE, null, ex);
        }
        //Comida 2
        try {
            comida2 = new ComidaConstante(100, fecha3, ultima);
        } catch (Excepcioncomida ex) {
            Logger.getLogger(AlgoritmosOrdenacion.class.getName()).log(Level.SEVERE, null, ex);
        }
        //Comida 3
        try {
            comida3 = new ComidaConstante(100, fecha2, ultima);
        } catch (Excepcioncomida ex) {
            Logger.getLogger(AlgoritmosOrdenacion.class.getName()).log(Level.SEVERE, null, ex);
        }
        Poblacionbacteria a = null;
        Poblacionbacteria b = null;
        Poblacionbacteria c = null;
        try {
            //poblacion 1
            a = new Poblacionbacteria("A", comida1, 100, 40, luminosidad.Alta);
            //Poblacion 2
            b = new Poblacionbacteria("b", comida2, 1000, 40, luminosidad.Alta);
            //Poblacion 3
            c = new Poblacionbacteria("C", comida3, 700, 40, luminosidad.Alta);
        } catch (NumeroInicialBacteriasNoValidoException ex) {
            Logger.getLogger(AlgoritmosOrdenacion.class.getName()).log(Level.SEVERE, null, ex);

        }
        LinkedList<Poblacionbacteria> lista = new LinkedList<Poblacionbacteria>();
        lista.add(b);
        lista.add(c);
        lista.add(a);
        //ORDENACION POR NOMBRE
        OrdenacionPorNombre(lista);
        for (Poblacionbacteria e : lista) {
            System.out.println(e);
        }
        //ORDENACION POR NUMERO DE BACTERIAS INICIALES
        OrdenacionPorBacteriasIniciales(lista);
        for (Poblacionbacteria e : lista) {
            System.out.println(e);
        }
        //ORDENACION POR FECHA DE COMIENZO
        OrdenacionPorFecha(lista);
        for (Poblacionbacteria e : lista) {
            System.out.println(e);
        }
//    

    }
}
