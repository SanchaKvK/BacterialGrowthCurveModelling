package practica;

import excepciones.MismaPoblacionException;
import excepciones.NoExistePoblacion;
import excepciones.Excepcioncomida;
import excepciones.Excepcionfecha;
import excepciones.NumeroInicialBacteriasNoValidoException;
import ClasesAuxiliares.Comida;
import ClasesAuxiliares.ComidaConstante;
import ClasesAuxiliares.Fecha;
import static practica.AlgoritmosOrdenacion.OrdenacionPorBacteriasIniciales;
import static practica.AlgoritmosOrdenacion.OrdenacionPorFecha;
import static practica.AlgoritmosOrdenacion.OrdenacionPorNombre;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * La clase Experimento contiene un LinkedList de clase Poblacionbacteria. Sirve
 * para guardar una cantidad variable de poblaciones de bacterias.
 *
 * @author sanchavonknobloch
 */
public class Experimento {

    private LinkedList<Poblacionbacteria> poblacion1 = new LinkedList<Poblacionbacteria>();

    /**
     * El constructor obligatoriamente requiere la creacion de una primera
     * poblacion de bacterias a ingresar en el experimento.
     *
     * @param primerapoblacion
     */
    public Experimento(Poblacionbacteria primerapoblacion) {
        this.poblacion1.add(primerapoblacion);
    }

    //para recoger datos de fichero, que no queremos meter una poblacioninicial;
    public Experimento() {
    }

    public LinkedList<Poblacionbacteria> getPoblacionesBacteria() {
        return poblacion1;
    }

    public Poblacionbacteria getPoblacionBacteria(String nombrepoblacion) throws NoExistePoblacion {
        return poblacion1.get(encontrarPoblacionBacteriaPorNombre(nombrepoblacion));
    }

    /**
     * El metodo encontrarPoblacionBacteriaPorPoblacion busca una poblacion
     * entre las poblaciones del atributo poblacion1, devolviendo el indice de
     * donde esta en caso de que lo encuentre
     *
     * @param poblacion la poblacion a buscar
     * @return el indice en el que se encuentra la poblacion
     * @throws NoExistePoblacion en caso de que la poblacion no este dentro del
     * grupo de poblaciones del atributo poblacion1.
     */
    private int encontrarPoblacionBacteriaPorPoblacion(Poblacionbacteria poblacion) throws NoExistePoblacion {
        int i = 0;
        boolean poblacionencontrada = false;
        for (i = 0; i < poblacion1.size() && poblacionencontrada == false; i++) {
            if ((poblacion1.get(i)).equals(poblacion) && poblacion1.get(i).hashCode() == poblacion1.get(i).hashCode()) {
                poblacionencontrada = true;
                return i;
            }
        }
        if (poblacionencontrada == false) {
            throw new NoExistePoblacion();
        }
        return i;
    }

    /**
     * El metodo añadirPoblacion sirve para añadir una poblacion de bacterias al
     * linkedlist de poblaciones de bacterias llamado poblacion1.
     *
     * @param poblacion a meter en el array (de tipo Poblacionbacteria)
     * @throws MismaPoblacionException en caso de que ya exista la poblacion que
     * se desea añadir
     */
    public void añadirPoblacion(Poblacionbacteria poblacion) throws MismaPoblacionException {
        try {
            encontrarPoblacionBacteriaPorPoblacion(poblacion);
            throw new MismaPoblacionException();
        } catch (NoExistePoblacion e) {
            poblacion1.add(poblacion);
        }
    }

    /**
     * El metodo encontrarPoblacionBacteriaPorNombre sirve para encontar una
     * poblacion de bacteria con el nombre que se le pasa por parametro.
     *
     * @param nombrepoblacion el String que representa el nombre de la poblacion
     * @return el indice (valor entero) en el que se encuentra la poblacion con
     * dicho nombre
     * @throws NoExistePoblacion en caso de que no haya nignuna poblacion con
     * ese nombre
     */
    private int encontrarPoblacionBacteriaPorNombre(String nombrepoblacion) throws NoExistePoblacion {
        int encontrado = 0;
        int i;
        for (i = 0; i < poblacion1.size() && encontrado == 0; i++) {
            if (nombrepoblacion.equals(poblacion1.get(i).getNombre())) {
                encontrado = 1;
                return i;
            }
        }
        if (i == poblacion1.size()) {
            throw new NoExistePoblacion();
        }
        return i;
    }

    /**
     * El metodo borrarPoblacionBacteria sirve para que una poblacion del array
     * de poblaciones de las bacterias ya no se incluya. Para esto, se introduce
     * como parametro un string que representa el nombre de la poblacion que se
     * quiere "eliminar" del conjunto de poblaciones ( array de objeto
     * Poblacionbacteria) llamado poblacion, y que se comparará con los nombres
     * de las poblaciones en el array. Si en algun momento los nombres son
     * iguales, entonces se realizará la eliminacion.
     *
     * @param nombre de la poblacion que se desea eliminar
     * @throws NoExistePoblacion si el parametro string no coincide con ningun
     * nombre de las poblaciones del array poblacion (atributo de clase
     * experimento)
     */
    public void borrarPoblacionBacteria(String nombrepoblacion) throws NoExistePoblacion {
        int i = encontrarPoblacionBacteriaPorNombre(nombrepoblacion);
        poblacion1.remove(poblacion1.get(i));
    }

    /**
     * El metodo visualizarNombres() sirve para meter los nombres de todas las
     * poblaciones del atributo poblacion1 de un experimento en un formato de
     * array de Strings. 
     *
     * @return array string con los nombres de las poblaciones de bacterias.
     */
    public String[] visualizarNombres() {
        String nombrespoblaciones[] = new String[poblacion1.size()];
        for (int i = 0; i < poblacion1.size(); i++) {
            nombrespoblaciones[i] = poblacion1.get(i).getNombre();
        }
        return nombrespoblaciones;
    }

    /*Ahora crearemos un main en el que probaremos los metodos de la clase
    experimento: ej: añadir una poblacion de bacterias al experimento. 
     */
//MAIN DE PRUEBA
    public static void main(String[] args) {
        Fecha fecha1 = null;
        Fecha fecha2 = null;
        Fecha fecha3 = null;
        Poblacionbacteria.luminosidad luz = Poblacionbacteria.luminosidad.Alta;
        try {
            fecha1 = new Fecha(10, 10, 2020);
            fecha2 = new Fecha(12, 10, 2020);
            fecha3 = new Fecha(18, 1, 2021);
        } catch (Excepcionfecha ex) {

        }
        //fecha fin
        Fecha ultima = null;
        try {
            ultima = new Fecha(10, 12, 2022);
        } catch (Excepcionfecha ex) {
        }
        Comida comida1 = null;
        Comida comida2 = null;
        Comida comida3 = null;
        //Comida 1 
        try {
            comida1 = new ComidaConstante(100, fecha1, ultima);
        } catch (Excepcioncomida ex) {
            Logger.getLogger(AlgoritmosOrdenacion.class.getName()).log(Level.SEVERE, null, ex);
        }
        //Comida 2
        try {
            comida2 = new ComidaConstante(100, fecha3, ultima);
        } catch (Excepcioncomida ex) {
            Logger.getLogger(AlgoritmosOrdenacion.class.getName()).log(Level.SEVERE, null, ex);
        }
        //Comida 3
        try {
            comida3 = new ComidaConstante(100, fecha2, ultima);
        } catch (Excepcioncomida ex) {
            Logger.getLogger(AlgoritmosOrdenacion.class.getName()).log(Level.SEVERE, null, ex);
        }
        Poblacionbacteria a = null;
        Poblacionbacteria b = null;
        Poblacionbacteria c = null;
        try {
            //poblacion 1
            a = new Poblacionbacteria("A", comida1, 100, 40, Poblacionbacteria.luminosidad.Alta);
            //Poblacion 2
            b = new Poblacionbacteria("b", comida2, 1000, 40, Poblacionbacteria.luminosidad.Alta);
            //Poblacion 3
            c = new Poblacionbacteria("A", comida1, 1000, 40, Poblacionbacteria.luminosidad.Alta);
        } catch (NumeroInicialBacteriasNoValidoException ex) {
            Logger.getLogger(AlgoritmosOrdenacion.class.getName()).log(Level.SEVERE, null, ex);
        }
        Experimento exp1 = new Experimento(a);
        try {
            exp1.añadirPoblacion(c);
        } catch (MismaPoblacionException ex) {
            System.out.println("NO DEJA PORQUE TIENE EL MISMO NOMBRE");
        }
        try {
            exp1.añadirPoblacion(b);
        } catch (MismaPoblacionException ex) {
            System.out.println("NO DEJA PORQUE TIENE EL MISMO NOMBRE");
        }

        String[] visualizar = exp1.visualizarNombres();
        for (int i = 0; i < visualizar.length; i++) {
            System.out.println(visualizar[i]);
        }
        try {
            exp1.borrarPoblacionBacteria("D");
        } catch (NoExistePoblacion ex) {
            System.out.println("no se puede borrar");
        }
    }
}
