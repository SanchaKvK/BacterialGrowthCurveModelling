/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica;

import ClasesAuxiliares.Comida;
import ClasesAuxiliares.ComidaConstante;
import ClasesAuxiliares.ComidaIncrementoDecremento;
import ClasesAuxiliares.ComidaIncrementoLineal;
import ClasesAuxiliares.ComidaIntermitente;
import ClasesAuxiliares.Fecha;
import excepciones.ExcepcionEstructuraIncorrecta;
import excepciones.Excepcioncomida;
import excepciones.Excepcionfecha;
import excepciones.MismaPoblacionException;
import excepciones.NumeroInicialBacteriasNoValidoException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.logging.Level;
import java.util.logging.Logger;
import practica.Experimento;
import practica.Poblacionbacteria;
import practica.Poblacionbacteria.luminosidad;

/**
 * La clase InputOutputFile contiene dos funciones especificas para realizar el
 * paso a fichero de un experimento y la devolucion de un experimento desde el
 * fichero.
 *
 * @author sanchavonknobloch
 */
public class FuncionesFichero {

    /**
     * La funcion readExperimentFromFile lee un fichero que contenga poblaciones
     * de bacterias y devuelve un experimento con ellas.
     *
     * @param fichero es la ruta del fichero.
     * @return devuele un experimento
     * @throws FileNotFoundException en el caso de que el fichero ingresado no
     * exista
     * @throws MismaPoblacionException esta excepcion nunca se lanzará en este
     * trozo del codigo puesto que ya ha sido chequeado antes de meterlo en el
     * fichero, pero al ser una excepcion obligatoria se debe lanzar.
     * @throws IOException en el caso de que haya algun error abriendo el
     * fichero o leyendolo se lanzará esta excepcion
     * @throws ExcepcionEstructuraIncorrecta si el contenido del fichero no esta
     * en el formato en el que esta establecido para recoger una poblacion de
     * bacterias
     * @throws Excepcionfecha nunca se lanzará puesto que tambien ha sido
     * comprobado antes de meter la poblacion en el fichero que el dia,mes y año
     * de una fecha estan en un rango valido
     * @throws Excepcioncomida no se lanzará
     * @throws NumeroInicialBacteriasNoValidoException no se lanzará
     */
    public static Experimento readExperimentFromFile(File fichero) throws FileNotFoundException, MismaPoblacionException, IOException, ExcepcionEstructuraIncorrecta, Excepcionfecha, Excepcioncomida, NumeroInicialBacteriasNoValidoException {
        Experimento experimentodevolver = new Experimento();
        BufferedReader in = new BufferedReader(new FileReader(fichero));
        String line;
        while ((line = in.readLine()) != null) {
            String valores[] = line.split(",");
            String nombrepoblacion = valores[0];
            int numerobacteriasinicial = Integer.parseInt(valores[1]);
            float temperatura = Float.parseFloat(valores[2]);
            String luminosidadvalor = (valores[3]);
            //lo inicicializamos con un valor cualquiera
            Poblacionbacteria.luminosidad luz = luminosidad.Alta;
            if (luminosidadvalor.equals("Alta")) {
                luz = Poblacionbacteria.luminosidad.Alta;
            }
            if (luminosidadvalor.equals("Media")) {
                luz = Poblacionbacteria.luminosidad.Media;
            }
            if (luminosidadvalor.equals("Baja")) {
                luz = Poblacionbacteria.luminosidad.Baja;
            }
            String tipocomida = valores[4];
            Comida comidapoblacion = null;
            Poblacionbacteria poblacionarchivo;

            if (tipocomida.equals("ComidaIncrementoDecremento")) {
                int diainicial = Integer.parseInt(valores[5]);
                int mesinicial = Integer.parseInt(valores[6]);
                int añoinicial = Integer.parseInt(valores[7]);
                Fecha fechainicial = new Fecha(diainicial, mesinicial, añoinicial);
                int ultimodiaincremento = Integer.parseInt(valores[8]);
                int ultimomesincremento = Integer.parseInt(valores[9]);
                int ultimoañoincremento = Integer.parseInt(valores[10]);
                Fecha fechaincremento = new Fecha(ultimodiaincremento, ultimomesincremento, ultimoañoincremento);
                int diafinal = Integer.parseInt(valores[11]);
                int mesfinal = Integer.parseInt(valores[12]);
                int añofinal = Integer.parseInt(valores[13]);
                Fecha fechafinal = new Fecha(diafinal, mesfinal, añofinal);
                int comidainicial = Integer.parseInt(valores[14]);
                int comidaultimodiaincremento = Integer.parseInt(valores[15]);
                int comidafinal = Integer.parseInt(valores[16]);
                comidapoblacion = new ComidaIncrementoDecremento(fechainicial,fechaincremento ,fechafinal, comidainicial, comidaultimodiaincremento, comidafinal);
                poblacionarchivo = new Poblacionbacteria(nombrepoblacion, comidapoblacion, numerobacteriasinicial, temperatura, luz);
            }
            if (tipocomida.equals("ComidaIncrementoLineal")) {
                int diainicial = Integer.parseInt(valores[5]);
                int mesinicial = Integer.parseInt(valores[6]);
                int añoinicial = Integer.parseInt(valores[7]);
                Fecha fechainicial = new Fecha(diainicial, mesinicial, añoinicial);
                int diafinal = Integer.parseInt(valores[8]);
                int mesfinal = Integer.parseInt(valores[9]);
                int añofinal = Integer.parseInt(valores[10]);
                Fecha fechafinal = new Fecha(diafinal, mesfinal, añofinal);
                int comidainicial = Integer.parseInt(valores[11]);
                int comidafinal = Integer.parseInt(valores[12]);
                comidapoblacion = new ComidaIncrementoLineal(fechainicial, fechafinal, comidainicial, comidafinal);
                poblacionarchivo = new Poblacionbacteria(nombrepoblacion, comidapoblacion, numerobacteriasinicial, temperatura, luz);
            }

            if (tipocomida.equals("ComidaConstante")) {
                int diainicial = Integer.parseInt(valores[5]);
                int mesinicial = Integer.parseInt(valores[6]);
                int añoinicial = Integer.parseInt(valores[7]);
                Fecha fechainicial = new Fecha(diainicial, mesinicial, añoinicial);
                int diafinal = Integer.parseInt(valores[8]);
                int mesfinal = Integer.parseInt(valores[9]);
                int añofinal = Integer.parseInt(valores[10]);
                Fecha fechafinal = new Fecha(diafinal, mesfinal, añofinal);
                int comidainicial = Integer.parseInt(valores[11]);
                comidapoblacion = new ComidaConstante(comidainicial, fechainicial, fechafinal);
                poblacionarchivo = new Poblacionbacteria(nombrepoblacion, comidapoblacion, numerobacteriasinicial, temperatura, luz);

            }
            if (tipocomida.equals("ComidaIntermitente")) {
                int diainicial = Integer.parseInt(valores[5]);
                int mesinicial = Integer.parseInt(valores[6]);
                int añoinicial = Integer.parseInt(valores[7]);
                Fecha fechainicial = new Fecha(diainicial, mesinicial, añoinicial);
                int diafinal = Integer.parseInt(valores[8]);
                int mesfinal = Integer.parseInt(valores[9]);
                int añofinal = Integer.parseInt(valores[10]);
                Fecha fechafinal = new Fecha(diafinal, mesfinal, añofinal);
                int comidainicial = Integer.parseInt(valores[11]);
                comidapoblacion = new ComidaIntermitente(fechainicial, fechafinal, comidainicial);
                poblacionarchivo = new Poblacionbacteria(nombrepoblacion, comidapoblacion, numerobacteriasinicial, temperatura, luz);
            }
            poblacionarchivo = new Poblacionbacteria(nombrepoblacion, comidapoblacion, numerobacteriasinicial, temperatura, luz);
            experimentodevolver.añadirPoblacion(poblacionarchivo);
        }
        if (in != null) {
            in.close();
        }
        return experimentodevolver;
    }

    /**
     * La funcion WriteExperimentToFile sirve para guardar un experimento en un
     * fichero.
     *
     * @param fichero requiere la ruta del fichero
     * @param experimentometer es el experimento que se desea guardar.
     * @throws IOException
     */
    public static void WriteExperimentToFile(File fichero, Experimento experimentometer) throws IOException {
        if (!fichero.exists()) {
            fichero.createNewFile();
        }
        PrintWriter out = new PrintWriter(new FileWriter(fichero, false));
        for (int i = 0; i < experimentometer.getPoblacionesBacteria().size(); i++) {
            out.println(experimentometer.getPoblacionesBacteria().get(i).toFile());
        }
        out.close();
    }

    public static void main(String[] args) {
        
    Fecha fecha1;
        try {
            fecha1 = new Fecha(10,10,2000);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(FuncionesFichero.class.getName()).log(Level.SEVERE, null, ex);
        }
    Fecha fechapico1;
        try {
            fechapico1 = new Fecha(12,10,2000);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(FuncionesFichero.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    luminosidad a = luminosidad.Alta;
    
    Fecha fecha2=null;
        try {
            fecha2 = new Fecha(11,10,2000);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(FuncionesFichero.class.getName()).log(Level.SEVERE, null, ex);
        }
    Fecha fechapico2=null;
        try {
            fechapico2 = new Fecha(13,10,2000);
        } catch (Excepcionfecha ex) {
            Logger.getLogger(FuncionesFichero.class.getName()).log(Level.SEVERE, null, ex);
        }
    Comida comida2=null;
        try {
            comida2 = new ComidaIncrementoLineal(fecha2,fechapico2,101,161);
        } catch (Excepcioncomida ex) {
            Logger.getLogger(FuncionesFichero.class.getName()).log(Level.SEVERE, null, ex);
        }
    luminosidad b = luminosidad.Baja;
    Poblacionbacteria p1=null;
        try {
            p1 = new Poblacionbacteria("p2",comida2,11,41,b);
        } catch (NumeroInicialBacteriasNoValidoException ex) {
            Logger.getLogger(FuncionesFichero.class.getName()).log(Level.SEVERE, null, ex);
        }
    Experimento experimento1 = new Experimento(p1);
        try {
            experimento1.añadirPoblacion(p1);
        } catch (MismaPoblacionException ex) {
            Logger.getLogger(FuncionesFichero.class.getName()).log(Level.SEVERE, null, ex);
        }
    File file1 = null;
    try {
        file1 = new File("/Users/sanchavonknobloch/NetBeansProjects/PRACTICA/test/Poblaciones.txt");
                        if (!file1.exists()) {
                            file1.createNewFile();
                        }
                        PrintWriter out = new PrintWriter(new FileWriter(file1,false));
                      for (int i = 0; i<experimento1.getPoblacionesBacteria().size();i++) {
                           out.println(experimento1.getPoblacionesBacteria().get(i).toFile());
                        }
                        out.close();
                    } catch (IOException excepcion) {
                        excepcion.printStackTrace();
                    } catch (InputMismatchException excepcion) {
                        System.out.println("Tiene que ser texto");
                    } catch (NullPointerException excepcion) {
                        System.out.println("Primero se debe abrir un fichero o guardar como");
                    }
file1 = new File("/Users/sanchavonknobloch/NetBeansProjects/PRACTICA/test/Poblaciones.txt");
Experimento experimento2 = null;
        try {
            experimento2 = readExperimentFromFile(file1);
        } catch (MismaPoblacionException ex) {
            Logger.getLogger(FuncionesFichero.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FuncionesFichero.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ExcepcionEstructuraIncorrecta ex) {
            Logger.getLogger(FuncionesFichero.class.getName()).log(Level.SEVERE, null, ex);
        
        } catch (Excepcionfecha ex) {
            Logger.getLogger(FuncionesFichero.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Excepcioncomida ex) {
            Logger.getLogger(FuncionesFichero.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NumeroInicialBacteriasNoValidoException ex) {
            Logger.getLogger(FuncionesFichero.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
                        for (String e : experimento1.visualizarNombres()) {
                            System.out.println(e);
                        }
                    } catch (NullPointerException excepcion) {
                        System.out.println("No se ha creado el experimento aun");
                    }
    }
}
