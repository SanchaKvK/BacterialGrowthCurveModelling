/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica;

import ClasesAuxiliares.Bacteria;
import ClasesAuxiliares.Comida;
import ClasesAuxiliares.ComidaConstante;
import ClasesAuxiliares.ComidaIncrementoDecremento;
import ClasesAuxiliares.ComidaIncrementoLineal;
import ClasesAuxiliares.ComidaIntermitente;
import ClasesAuxiliares.Fecha;
import excepciones.Excepcioncomida;
import excepciones.Excepcionfecha;
import excepciones.NoExisteCeldaException;
import excepciones.NumeroInicialBacteriasNoValidoException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * La clase Poblacionbacteria representa una poblacion que tiene un valor entero
 * que representa el numero de bacterias inicial, un nombre, una cantidad de
 * luz, representada por la enumeracion luminosidad, una temperatura especifica
 * (numero real) ademas de un atributo de tipo Comida. Tambien contiene dos
 * atributos utilizados para calcular la simulacion de montecarlo, un array
 * bidimensional para guardar la comida de cada dia y un linkedlist de la clase
 * Bacteria.
 *
 * @author sanchavonknobloch
 */
public class Poblacionbacteria {

    private String nombre = "";
    private final Comida comidapoblacion;
    private final int numerobacteriasinicial;
    private final float temperatura;
    private luminosidad luz;
    private int[][] comidacelda = new int[20][20];
    private LinkedList<Bacteria> grupobacterias = new LinkedList<Bacteria>();

    /**
     * La enumeracion luminosidad permite tener tres valores: Alta, Media, Baja.
     */
    public enum luminosidad {
        Alta("La luminosidad es alta"),
        Media("la luminosidad es media"),
        Baja("La luminosidad es baja");
        private String luz;

        luminosidad(String luz) {
            this.luz = luz;
        }

        public String getLuminosidad() {
            return this.luz;
        }
    };

    /**
     * El constructor de la Poblaciobacteria se le pasan
     *
     * @param nombre nombre de la poblacion
     * @param comidapoblacion un objeto Comida
     * @param numerobacteriasinicial el numero de bacterias inicial de la
     * poblacion
     * @param temperatura la temperatura a la que se mantiene la poblacion
     * (float)
     * @param luz la luminosidad a la que esta expuesta la poblacion
     * (enumeracion luminosidad)
     */
    public Poblacionbacteria(String nombre, Comida comidapoblacion, int numerobacteriasinicial, float temperatura,
            luminosidad luz) throws NumeroInicialBacteriasNoValidoException {
        if (numerobacteriasinicial < 0) {
            throw new NumeroInicialBacteriasNoValidoException();
        }
        this.nombre = nombre;
        this.comidapoblacion = comidapoblacion;
        this.numerobacteriasinicial = numerobacteriasinicial;
        this.temperatura = temperatura;
        this.luz = luz;
    }

    /**
     * La funcion duracionPoblacion() calcula la cantidad de dias que hay entre
     * la fecha de inicio y la final, y se utiliza dentro de la funcion
     * Montecarlo para calcular la cantidad de veces que hay que realizar el
     * algoritmo.
     *
     * @return la cantidad de dias.
     */
    private int duracionPoblacion() {
        LocalDate fechainicial = LocalDate.of(comidapoblacion.fechainicio.getAño(), comidapoblacion.fechainicio.getMes(), comidapoblacion.fechainicio.getDia());
        LocalDate fechafinal = LocalDate.of(comidapoblacion.fechafin.getAño(), comidapoblacion.fechafin.getMes(), comidapoblacion.fechafin.getDia());
        int numerodedias = (int) ChronoUnit.DAYS.between(fechainicial, fechafinal);
        return numerodedias;
    }

    /**
     * La funcion ReparticionBacteriasInicial añade bacterias e inicializa los
     * valores de su localizacionfila y localizacioncolumna en base al numero de
     * bacterias iniciales de la poblacion.
     */
    private void ReparticionBacteriasInicial() {
        int numeroporcelda = numerobacteriasinicial / 16;
        for (int fila = 8; fila <= 11; fila++) {
            for (int columna = 8; columna <= 11; columna++) {
                for (int numerobacteriasencelda = 0; numerobacteriasencelda < numeroporcelda; numerobacteriasencelda++) {
                    Bacteria bacteriameter = new Bacteria(fila, columna);
                    grupobacterias.add(bacteriameter);
                }
            }
        }
    }

    /**
     * La función SuminstroComidaDiaria introduce los cantidad de comida que
     * tiene cada celda por dia durante la duracion de la poblacion.
     *
     * @param dia el dia de la poblacion del que se quiere saber la comida de 
     * cada celda
     */
    private void SuministroComidaDiaria(int dia) {
        int comidasuministrar = comidapoblacion.CantidadComidaDiaN(dia);
        int comidaporcelda = comidasuministrar / 400;
        for (int fila = 0; fila < 20; fila++) {
            for (int columna = 0; columna < 20; columna++) {
                comidacelda[fila][columna] += comidaporcelda;
            }
        }
    }

    /**
     *La funcion Montecarlo calcula una cantidad posible de bacterias por
     * cada dia de la duración de la poblacion.
     * @return devuelve un array unidimensional con la cantidad de bacterias
     * de cada dia
     */
    public int[][][] Montecarlo() {
        //esta borrar
        int numerobacteriasporceldapordia[][] = new int[20][20];
        int duracionpoblacion = duracionPoblacion();
        //esta borrar
        int[][][] bacteriaspordiaarray = new int[duracionpoblacion][20][20];
        ReparticionBacteriasInicial();
        //esta meter como devuelve 
        int[] bacteriaspordia = new int[duracionpoblacion];
        //int[][][] bacteriasycomidarestantecadadia = new int[duracionpoblacion][20][20];
        //reparto las bacterias en las dieciseis celdas centrales
        ReparticionBacteriasInicial();
        for (int dia = 0; dia < duracionpoblacion; dia++) {
            //reparto la comida del dia
            SuministroComidaDiaria(dia);
            int cantidadbacteriasprincipiodia = grupobacterias.size();
            //metemos el numero de bacterias al iniciar el dia, porque despues se suman las bacterias 
            //hijas que se crean al grupobacterias.size() pero nosotros solamente queremos calcular para
            //las bacterias con las que empezamos el dia. 
            //las bacterias hijas seran manipuladas al dia siguiente
            for (int bacteria = 0; bacteria < cantidadbacteriasprincipiodia; bacteria++) {
                int repeticion = 0;
                int comebacteria = 0;
                boolean celdaencontrada;
                do {
                    celdaencontrada = false;
                    for (int fila = 0; fila < 20 && celdaencontrada == false; fila++) {
                        for (int columna = 0; columna < 20 && celdaencontrada == false; columna++) {
                            if (grupobacterias.get(bacteria).getFilai() == fila && grupobacterias.get(bacteria).getColumnaj() == columna) {
                                celdaencontrada = true;
                                int opcion = 0;
                                if (comidacelda[fila][columna] >= 100) {
                                    opcion = 1;
                                }
                                if (comidacelda[fila][columna] > 9 && comidacelda[fila][columna] < 100) {
                                    opcion = 2;
                                }
                                if (comidacelda[fila][columna] < 9) {
                                    opcion = 3;
                                }
                                switch (opcion) {
                                    case 1: {
                                        comebacteria += 20;
                                        comidacelda[fila][columna] -= 20;
                                        try {
                                            grupobacterias.get(bacteria).CeldaTipo1(fila, columna);
                                        } catch (NoExisteCeldaException ex) {
                                            //quiere decir que no se puede mover a la celda indicada porque esta fuera del 20x20
                                            //por lo que se queda en su celda.
                                            grupobacterias.get(bacteria).setFilai(fila);
                                            grupobacterias.get(bacteria).setColumnaj(columna);
                                        }
                                        break;
                                    }
                                    case 2: {
                                        comebacteria += 10;
                                        comidacelda[fila][columna] -= 10;
                                        try {
                                            grupobacterias.get(bacteria).CeldaTipo2(fila, columna);
                                        } catch (NoExisteCeldaException ex) {
                                            grupobacterias.get(bacteria).setFilai(fila);
                                            grupobacterias.get(bacteria).setColumnaj(columna);
                                        }
                                        break;
                                    }
                                    case 3: {
                                        try {
                                            grupobacterias.get(bacteria).CeldaTipo3(fila, columna);
                                        } catch (NoExisteCeldaException ex) {
                                            grupobacterias.get(bacteria).setFilai(fila);
                                            grupobacterias.get(bacteria).setColumnaj(columna);
                                        }
                                        break;
                                    }
                                } //switch
                            }  //if
                        } //forcolumnas
                    } //for filas
                    repeticion++;
                } while (grupobacterias.get(bacteria).getVivo() && repeticion < 10);
                //con la cantidad de comida de bacteriacomida si la bacteria sigue vivo
                if (grupobacterias.get(bacteria).getVivo() == true) {
                    if (comebacteria > 150) {
                        grupobacterias.add(new Bacteria(grupobacterias.get(bacteria).getFilai(), grupobacterias.get(bacteria).getColumnaj()));
                        grupobacterias.add(new Bacteria(grupobacterias.get(bacteria).getFilai(), grupobacterias.get(bacteria).getColumnaj()));
                        grupobacterias.add(new Bacteria(grupobacterias.get(bacteria).getFilai(), grupobacterias.get(bacteria).getColumnaj()));
                    }
                    if (comebacteria > 100 && comebacteria < 150) {
                        grupobacterias.add(new Bacteria(grupobacterias.get(bacteria).getFilai(), grupobacterias.get(bacteria).getColumnaj()));
                        grupobacterias.add(new Bacteria(grupobacterias.get(bacteria).getFilai(), grupobacterias.get(bacteria).getColumnaj()));
                    }
                    if (comebacteria > 50 && comebacteria < 100) {
                        grupobacterias.add(new Bacteria(grupobacterias.get(bacteria).getFilai(), grupobacterias.get(bacteria).getColumnaj()));
                    }
                }
            }
            //eliminamos las bacterias muertas 
            for (int bacteria = 0; bacteria < grupobacterias.size(); bacteria++) {
                if (grupobacterias.get(bacteria).getVivo() == false) {
                    grupobacterias.remove(bacteria);
                }
            }
            
           //Aqui empiezo sino borro
           int cantidadbacteriasencelda;
           for(int fila=0;fila<20;fila++){
            for(int columna=0;columna<20;columna++){
                cantidadbacteriasencelda =0;
                for(int i=0;i<grupobacterias.size();i++){
                if((grupobacterias.get(i).getFilai()==fila) && (grupobacterias.get(dia).getColumnaj()==columna)){
                    cantidadbacteriasencelda++;
                }
                 }
                
                numerobacteriasporceldapordia[fila][columna]=cantidadbacteriasencelda;
           }
           }
            for(int fila=0;fila<20;fila++){
                for(int columna=0;columna<20;columna++){
            bacteriaspordiaarray[dia][fila][columna]= numerobacteriasporceldapordia[fila][columna];
                    }
            }
           //AQUI TERMINO
            
            //contamos la cantidad de bacterias en el dia
            bacteriaspordia[dia] = grupobacterias.size();

        }
        //return bacteriaspordia;
        return bacteriaspordiaarray;
    }                        

    public Comida getComida() {
        return comidapoblacion;
    }

    public String getNombre() {
        return this.nombre;
    }

    public int getNumeroBacteriasInicial() {
        return this.numerobacteriasinicial;
    }

    /**
     * El metodo toFile perimte imprimir el contenido de un objeto de tipo
     * Poblacionbacteria con la estructura declarada: los enteros que
     * representan cantidades de comida, y las fechas, separadas entre barras
     * asi como la luminosidad, temperatura, el nombre y el numero de bacterias
     * inicial de la poblacion.
     *
     * @return el string de los atributos de un objeto de tipo Poblacionbacteria
     * separados por comas.
     */
    public String toFile() {
        return nombre + "," + numerobacteriasinicial + "," + temperatura + "," + luz + "," + comidapoblacion.toFile();
    }

    /**
     * El metodo toString perimte imprimir el contenido de un objeto de tipo
     * Poblacionbacteria con la estructura declarada.
     *
     * @return el string que representa el objeto Poblacionbacteria
     */
    @Override
    public String toString() {
        return "NOMBRE:    " + nombre + "\n\nNUMERO DE BACTERIAS:    " + numerobacteriasinicial + ""
                + "\n\nTEMPERATURA(EN GRADOS)    :" + temperatura + "\n\nLUMINOSIDAD:    " + luz.getLuminosidad() + "\n\n  COMIDA: \n\n" + comidapoblacion;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.nombre);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Poblacionbacteria other = (Poblacionbacteria) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        return true;
    }

    /* Ahora crearemos un objeto de tipo Poblacionbacteria en el main e 
    imprimiremos el contenido del objeto con el metodo toString(). 
     */
    //MAIN DE PRUEBA
    public static void main(String[] args) {
        Poblacionbacteria poblacion = null;
        Fecha fecha1 = null;
        LinkedList<Bacteria> reparticion = null;
        try {
            fecha1 = new Fecha(10, 10, 2020);
        } catch (Excepcionfecha ex) {

        }
        Fecha fechaultimodiaincremento = null;
        try {
            fechaultimodiaincremento = new Fecha(21, 10, 2020);
        } catch (Excepcionfecha ex) {
        }
        Fecha ultima = null;
        try {
            ultima = new Fecha(15, 12, 2020);
        } catch (Excepcionfecha ex) {
        }
        int comidainicial = 1000;
        int comidaultimodiaincremento = 3000;
        try {
            //PROBAMOS CON COMIDA CONSTANTE
            Comida comida1 = new ComidaConstante(1000,fecha1,fechaultimodiaincremento);
        } catch (Excepcioncomida ex) {
            Logger.getLogger(Poblacionbacteria.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            //PROBAMOS CON COMIDA INTERMITENTE
            Comida comida1 = new ComidaIntermitente(fecha1,fechaultimodiaincremento,1000);
        } catch (Excepcioncomida ex) {
            Logger.getLogger(Poblacionbacteria.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            //PROBAMOS CON INCREMENTO LINEAL
            Comida comida1 = new ComidaIncrementoLineal(fecha1,fechaultimodiaincremento,10000,20000);
        } catch (Excepcioncomida ex) {
            Logger.getLogger(Poblacionbacteria.class.getName()).log(Level.SEVERE, null, ex);
        }
        //PROBAMOS INCREMENTO DECREMENTO LINEAL
        Comida comida1 = null;
        try {
            comida1 = new ComidaIncrementoLineal(fecha1, fechaultimodiaincremento, 10000, 29999);
        } catch (Excepcioncomida ex) {
            System.out.println("Se ha intentado añadir un valor de comida o mayor a 300000 o menor a 1");
        }
        try {
            poblacion = new Poblacionbacteria("Juan", comida1, 48, 40, luminosidad.Media);
        } catch (NumeroInicialBacteriasNoValidoException ex) {
            System.out.println("El numero de bacterias inicial no es valido");
        }
        //int[] array = poblacion.Montecarlo();
        //for (int i = 0; i < array.length; i++) {
        //    System.out.println(array[i]);
        //}
    }

}
