/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inputOutput;

import excepciones.Excepcioncomida;
import excepciones.Excepcionfecha;
import excepciones.NumeroInicialBacteriasNoValidoException;
import excepciones.Excepcionenumeracion;
import ClasesAuxiliares.Fecha;
import ClasesAuxiliares.Comida;
import ClasesAuxiliares.ComidaConstante;
import ClasesAuxiliares.ComidaIncrementoDecremento;
import ClasesAuxiliares.ComidaIncrementoLineal;
import ClasesAuxiliares.ComidaIntermitente;
import static practica.AlgoritmosOrdenacion.OrdenacionPorBacteriasIniciales;
import static practica.AlgoritmosOrdenacion.OrdenacionPorFecha;
import static practica.AlgoritmosOrdenacion.OrdenacionPorNombre;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import static java.lang.System.exit;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import practica.*;
import practica.Poblacionbacteria.luminosidad;
import static practica.FuncionesFichero.WriteExperimentToFile;
import static practica.FuncionesFichero.readExperimentFromFile;

/**
 * La clase InputOutput es la clase desde la cual se realiza la comunicación con
 * el usuario con el fin de crear los distintos objetos necesarios para realizar
 * objetos de tipo Poblacionbacteria que mas tarde se manipularan dentro de un
 * objeto de tipo Experimento.
 *
 * @author sanchavonknobloch
 */
public class InputOutput {

//CREAR FECHA : mediante la funcion crearFecha() y CrearFecha()
    /**
     * La funcion crearFecha() es utilizada para pedir al usuario los atributos
     * de un objeto de tipo Fecha.
     *
     * @return Devuelve la fecha creada
     * @throws Excepcionfecha si el dia,mes o año ingresado no es valido.
     */
    static private Fecha crearFecha() throws Excepcionfecha{
        boolean fechanovalida = false;
        int dia = 0;
        int mes = 0;
        int año = 0;
        do {
            try {
                System.out.println("Introduzca el dia");
                Scanner diascanner = new Scanner(System.in);
                dia = diascanner.nextInt();

                if (dia > 31 || dia < 1) {
                    throw new Excepcionfecha("dia");
                } else {
                    fechanovalida = true;
                }
            } catch (InputMismatchException excepcion) {
                System.out.println("Tiene que ser un numero entero");
            }
        } while (!fechanovalida);

        fechanovalida = false;
        do {
            try {
                System.out.println("Introduzca el mes");
                Scanner messcanner = new Scanner(System.in);
                mes = messcanner.nextInt();
                if (mes > 12 || mes < 1) {
                    throw new Excepcionfecha("mes");
                }
                if ((mes == 2 || mes == 4 || mes == 6 || mes == 9 || mes == 11) && dia == 31) {
                    throw new Excepcionfecha("combinacion");
                } else {
                    fechanovalida = true;
                }
            } catch (InputMismatchException excepcion) {
                System.out.println("Tiene que ser un numero entero");
            }
        } while (!fechanovalida);

        fechanovalida = false;
        do {
            System.out.println("Introduzca el año");
            Scanner añoscanner = new Scanner(System.in);
            año = añoscanner.nextInt();
            if (año < 1900) {
                throw new Excepcionfecha("año");
            } else {
                fechanovalida = true;
            }
        } while (!fechanovalida);
        Fecha fecha1 = new Fecha(dia, mes, año);
        return fecha1;
    }

    /**
     * La Funcion CrearFecha() se utiliza para crear un objeto de tipo Fecha.
     *
     * @return objeto Fecha creado y comprobado.
     */
    static private Fecha CrearFecha() {
        boolean noexcepcion = true;
        Fecha fecha1 = null;
        do {
            try {
                fecha1 = crearFecha();
                noexcepcion = true;
            } catch (Excepcionfecha excepcion) {
                if (excepcion.getMessage() == "dia") {
                    System.out.println("El dia debe ser un entero entre 1 y 31");
                    noexcepcion = false;
                }
                if (excepcion.getMessage() == "mes") {
                    System.out.println("El mes debe ser un entero entre 1 y 12");
                    noexcepcion = false;
                }
                if (excepcion.getMessage() == "año") {
                    System.out.println("El año debe ser mayor a 2020");
                    noexcepcion = false;
                }
                if (excepcion.getMessage() == "combinacion") {
                    System.out.println("Los meses de febrero,abril,junio,septiembre y noviembre no tienen 31 dias");
                    noexcepcion = false;
                }
            }
        } while (false == noexcepcion);
        return fecha1;
    }
    //meter un valor valido en el atributo comida

    /**
     * La funcion ValorComida sirve para pedirle al usuario el valor de la
     * comida
     *
     * @return un entero con el valor de la comida
     * @throws Excepcioncomida en caso de que el valor ingresado sea mayor a
     * 3000000 o menor a 1.
     */
    static private int ValorComida() throws Excepcioncomida {
        int comidainicial = 0;
        boolean comidaesentero = true;
        do {
            try {
                System.out.println("Introduzca el valor de la comida");
                Scanner scannercomida = new Scanner(System.in);
                comidainicial = scannercomida.nextInt();
                if (comidainicial >= 300000 || comidainicial <= 0) {
                    throw new Excepcioncomida("rango");
                }
            } catch (InputMismatchException ex) {
                System.out.println("Debe ser un entero");
                comidaesentero = false;
            }
        } while (comidaesentero == false);
        return comidainicial;
    }

    //CREAMOS COMIDA CONSTANTE
    /**
     * La funcion de tipo CrearComidaConstante crea un objeto de tipo
     * ComidaConstante
     *
     * @return la instancia de ComidaConstante creada.
     */
    static private ComidaConstante CrearComidaConstante() {
        Fecha fechainicio = null;
        Fecha fechafin = null;
        int comida = 0;
        boolean comidanovalida = true;
        boolean fechasnovalidas = true;
        do {
            System.out.println("Introducir la fecha de inicio de la poblacion");
            fechainicio = CrearFecha();
            System.out.println("Introducir la fecha de finalizacion de la poblacion");
            fechafin = CrearFecha();
            if (fechainicio.anteriorA(fechafin) == false) {
                fechasnovalidas = false;
                System.out.println("La fecha de finalizacion debe ser posterior a la de inicio");
            };

        } while (fechasnovalidas = false);
        ComidaConstante comida1 = null;
        do {
            try {
                comida = ValorComida();
            } catch (Excepcioncomida ex) {
                System.out.println("Debe ser un valor entero entre 1 y 300000");
                comidanovalida = true;
            }

        } while (comidanovalida == false);
        try {
            comida1 = new ComidaConstante(comida, fechainicio, fechafin);
        } catch (Excepcioncomida ex) {
            //ya esta mas que comprobado, pero al ponerlo que el constructor 
            //lanza la excepcion debo comprobarla otra vez. 
            ex.printStackTrace();
        }
        return comida1;
    }

    //CREAMOS COMIDA INTERMITENTE
    /**
     * La funcion CrearComidaIntermitente() crea un objeto de tipo
     * ComidaIntermitente
     *
     * @return la instancia de ComidaIntermitente
     */
    static private ComidaIntermitente CrearComidaIntermitente() {
        Fecha fechainicio = null;
        Fecha fechafin = null;
        int comida = 0;
        boolean comidanovalida = true;
        boolean fechanovalida;
        do {
            fechanovalida = true;
            System.out.println("Introducir la fecha de inicio de la poblacion");
            fechainicio = CrearFecha();
            System.out.println("Introducir la fecha de finalizacion de la poblacion");
            fechafin = CrearFecha();
            if (fechainicio.anteriorA(fechafin) == false) {
                fechanovalida = false;
                System.out.println("La fecha de finalizacion debe ser posterior a la de inicio");
            };
        } while (fechanovalida == false);
        ComidaIntermitente comida1 = null;
        do {
            try {
                System.out.println("Introduzca el valor de la comida");
                comida = ValorComida();
            } catch (Excepcioncomida ex) {
                System.out.println("Debe ser un valor entero entre 1 y 300000");
                comidanovalida = true;
            }
        } while (comidanovalida == false);
        try {
            comida1 = new ComidaIntermitente(fechainicio, fechafin, comida);
        } catch (Excepcioncomida ex) {
            //ya esta mas que comprobado, pero al ponerlo que el constructor 
            //lanza la excepcion debo comprobarla otra vez. 
            ex.printStackTrace();
        }
        return comida1;
    }

    /**
     * La funcion CrearComidaIncrementoLineal crea un objeto de tipo
     * ComidaIncrementoLineal
     *
     * @return el objeto creado de tipo ComidaIncrementoLineal
     */
    static private ComidaIncrementoLineal CrearComidaIncrementoLineal() {
        Fecha fechainicio = null;
        Fecha fechafin = null;
        int comidainicial = 0;
        int comidafinal = 0;
        boolean comidanovalida = true;
        boolean fechanovalida = true;
        ComidaIncrementoLineal comida1 = null;
        do {
            fechanovalida = true;
            System.out.println("Introducir la fecha de inicio de la poblacion");
            fechainicio = CrearFecha();
            System.out.println("Introducir la fecha de finalizacion de la poblacion");
            fechafin = CrearFecha();
            if (fechainicio.anteriorA(fechafin) == false) {
                fechanovalida = false;
                System.out.println("La fecha de finalizacion debe ser posterior a la de inicio");
            };
        } while (fechanovalida == false);
        do {
            comidanovalida = true;
            try {
                System.out.println("introduzca la comida del primer dia");
                comidainicial = ValorComida();
            } catch (Excepcioncomida ex) {
                System.out.println("Debe ser un valor entero entre 1 y 300000");
                comidanovalida = false;
            }
            try {
                System.out.println("introduzca la comida del ultimo dia");
                comidafinal = ValorComida();
            } catch (Excepcioncomida ex) {
                System.out.println("Debe ser un valor entero entre 1 y 300000");
                comidanovalida = false;
            }
            if (comidainicial >= comidafinal) {
                comidanovalida = false;
            }
        } while (comidanovalida == false);
        try {
            comida1 = new ComidaIncrementoLineal(fechainicio, fechafin, comidainicial, comidafinal);
        } catch (Excepcioncomida ex) {
            ex.printStackTrace();
        }
        return comida1;
    }
    /**
     * La funcion cantidadesComidaIncDec devuelve un array con los valores de
     * tipo entero de la comida inicial,comida el dia pico y comida el dia
     * final.
     *
     * @return array de enteros con valores de comida de tres dias distintos.
     * @throws Excepcioncomida en caso de que se ingrese una comida mayor a
     * 300000 o menor a 1.
     */
    static private int[] cantidadesComidaIncDec() throws Excepcioncomida {
        boolean comidanovalida = false;
        int comidainicial = 0;
        int comidapico = 0;
        int comidafinal = 0;
        int comidainfo[] = new int[3];
        do {
            try {
                System.out.println("Introduzca la cantidad de comida inicial");
                Scanner scannercomidainicial = new Scanner(System.in);
                comidainicial = scannercomidainicial.nextInt();
                if (comidainicial >= 300000 || comidainicial <= 0) {
                    throw new Excepcioncomida("rango");
                } else {
                    comidanovalida = true;
                }
            } catch (InputMismatchException excepcion) {
                System.out.println("Tiene que ser un valor de tipo entero");
            }
        } while (false == comidanovalida);
        comidanovalida = false;
        do {
            try {
                System.out.println("Introduzca la cantidad de comida final");
                Scanner scannercomidafinal = new Scanner(System.in);
                comidafinal = scannercomidafinal.nextInt();
                if (comidafinal >= 300000 || comidafinal <= 0) {
                    throw new Excepcioncomida("rango");
                } else {
                    comidanovalida = true;
                }
            } catch (InputMismatchException excepcion) {
                System.out.println("Tiene que ser un valor de tipo entero");
            }
        } while (false == comidanovalida);
        comidanovalida = false;
        do {
            try {
                System.out.println("Introduzca la cantidad de comida el ultimo dia que esta incrementa");
                Scanner scannercomidapico = new Scanner(System.in);
                comidapico = scannercomidapico.nextInt();
                if (comidapico >= 300000 || comidapico <= 0) {
                    throw new Excepcioncomida("rango");
                }
                if (comidapico <= comidafinal) {
                    throw new Excepcioncomida("comidafinal");
                }
                if (comidapico <= comidainicial) {
                    throw new Excepcioncomida("comidainicial");
                } else {
                    comidanovalida = true;
                }
            } catch (InputMismatchException excepcion) {
                System.out.println("Tiene que ser un valor de tipo entero");
            }
        } while (false == comidanovalida);

        comidainfo[0] = comidainicial;
        comidainfo[1] = comidapico;
        comidainfo[2] = comidafinal;

        return comidainfo;
    }

    /**
     * La funcion ComidaIncrementoDecremento crea un objeto de tipo
     * ComidaIncrementoDecremento
     *
     * @return el objeto de tipo ComidaIncrementoDecremento
     */
    static private ComidaIncrementoDecremento CrearComidaIncrementoDecremento() {
        Fecha fechainicio;
        Fecha fechapico;
        Fecha fechafin;
        int comidainicial;
        int comidapico;
        int comidafinal;
        int comidainfo[] = new int[3];
        boolean noexcepcion = false;
        do {
            try {
                comidainfo = cantidadesComidaIncDec();
                noexcepcion = true;
            } catch (Excepcioncomida excepcion) {
                if (excepcion.getMessage() == "rango") {
                    System.out.println("La comida debe ser un numero entero entre 1 y 300,000 ");
                    noexcepcion = false;
                }
                if (excepcion.getMessage() == "comidafinal") {
                    System.out.println("La comida final debe ser menor a la comida del ultimo dia de incremento de comida");
                    noexcepcion = false;
                }
                if (excepcion.getMessage() == "comidainicial") {
                    System.out.println("La comida inicial debe ser menor a la comida del ultimo dia de incremento de comida");
                    noexcepcion = false;
                }
            }
        } while (noexcepcion == false);
//los valores del array se vuelven a trasladar a variables de tipo int
        comidainicial = comidainfo[0];
        comidapico = comidainfo[1];
        comidafinal = comidainfo[2];
//estas variables servirán para instanciar la clase Comida. 
        System.out.println("Introduzca cuando la fecha en la que empezó la poblacion");
        fechainicio = CrearFecha();
        fechafin = CrearFecha();
        //fechafin = fechainicio.fechaFinal();
        System.out.println("Introduzca la fecha del ultimo dia en la que se incrementa la comida de la poblacion");
        fechapico = CrearFecha();
        //comprobamos que tanto la fecha pico es mayor a la fecha inicial como que la fecha final es mayor a la pico
        do {
            noexcepcion = true;
            if (fechainicio.anteriorA(fechapico) == false) {
                noexcepcion = false;
                System.out.println("La fecha del ultimo dia en la que se incrementa la comida de la poblacion tiene que"
                        + "estar entre la fecha" + fechainicio + "y" + fechafin);
                fechapico = CrearFecha();
            }
            if (fechapico.anteriorA(fechafin) == false) {
                noexcepcion = false;
                System.out.println("La fecha del ultimo dia en la que se incrementa la comida de la poblacion tiene que"
                        + "estar entre la fecha" + fechainicio + "y" + fechafin);
                fechapico = CrearFecha();
            }
        } while (noexcepcion == false); //mientras que la fechapico(fecha que representa el ultimo dia de incremento
        //de comida no este entre la fecha en la que comienza la poblacion y la fecha en la que termina. 
        ComidaIncrementoDecremento comida1 = null;
        try {
            comida1 = new ComidaIncrementoDecremento(fechainicio, fechapico, fechafin, comidainicial, comidapico, comidafinal);
            return comida1;
        } catch (Excepcioncomida ex) {
            ex.printStackTrace();
        }
        return comida1;
    }

    //CREAR ATRIBUTO ENUMERACION (despues se introducirá en una poblacion de bacterias).
    /**
     * La funcion ComprobarEnumeracion() comprueba que la enumeracion
     * luminosidad que será un atributo de la clase Poblacionbacteria se rellena
     * con un valor permitido.Tambien comprueba que se está ingresando texto y
     * no un numero.
     *
     * @return un string que representa el tipo de valor que la enumeracion
     * adoptará.
     * @throws Excepcionenumeracion si no se mete un string que sea igual a
     * "Alta" , "Media" o "Baja".
     */
    static private String ComprobarEnumeracion() throws Excepcionenumeracion {
        Boolean valido = false;
        String opcionluminosidad = "";
        do {
            try {
                System.out.println("Introduzca la luminosidad: (Alta, Media o Baja)");
                Scanner luminosidadpoblacion1 = new Scanner(System.in);
                opcionluminosidad = luminosidadpoblacion1.nextLine();
                if (opcionluminosidad.equals("Alta") || opcionluminosidad.equals("Media")
                        || opcionluminosidad.equals("Baja")) {
                    valido = true;
                } else {
                    throw new Excepcionenumeracion(opcionluminosidad);
                }
            } catch (InputMismatchException excepcion) {
                System.out.println("Debe ser una cadena de caracteres");
                valido = false;
            }
        } while (valido == false);
        return opcionluminosidad;
    }

    /**
     * La funcion CrearPoblacion() sirve para crear una poblacion de bacterias.
     *
     * @return un objeto de tipo Poblacionbacteria.
     */
    //CREAR POBLACION
    static public Poblacionbacteria CrearPoblacion() {
        String nombre = "";
        int numerobacteriasinicial = 0;
        float temperatura = 0F;
        String opcionluminosidad = "";
        luminosidad luz = luminosidad.Alta;
        Boolean valido = false;
        Comida comidapoblacion = null;
        do {
            try {
                System.out.println("Introduzca el nombre de la poblacion");
                Scanner nombrepoblacion = new Scanner(System.in);
                nombre = nombrepoblacion.nextLine();
                valido = true;
            } catch (InputMismatchException excepcion) {
                System.out.println("Tiene que ser una cadena de caracteres");
                valido = false;
            }
        } while (valido == false);
        // Temperatura
        valido = false;

        do {
            try {
                System.out.println("Introduzca la temperatura");
                Scanner temperaturapoblacion = new Scanner(System.in);
                temperatura = temperaturapoblacion.nextFloat();
                valido = true;
            } catch (InputMismatchException excepcion) {
                System.out.println("Tiene que introducir un valor de tipo real");
                valido = false;
            }
        } while (valido == false);

        valido = false;
        //Luminosidad
        do {
            try {
                opcionluminosidad = ComprobarEnumeracion();
                valido = true;
            } catch (Excepcionenumeracion excepcion) {
                System.out.println("Tiene que una de las tres opciones:Alta,Media,Baja");
                valido = false;
            }
        } while (valido == false);
        switch (opcionluminosidad) {
            case "Alta": {
                luz = luminosidad.Alta;
                break;
            }
            case "Media": {
                luz = luminosidad.Media;
                break;
            }
            case "Baja": {
                luz = luminosidad.Baja;
                break;
            }
        }
        //Comida de la poblacion;
        boolean numeroescogido = true;
        int numero = 0;
        do {
            try {
                System.out.println("Que formato de suministro de comida desea que tenga la poblacion:");
                System.out.println("1)constante");
                System.out.println("2)Incremento Lineal");
                System.out.println("3)Incremento hasta una fecha pico y despues decremento hasta el final");
                System.out.println("4)Intermitente");
                Scanner s = new Scanner(System.in);
                numero = s.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Debe ser un numero entero");
            }
            if (numero == 1 || numero == 2 || numero == 3 || numero == 3) {
                numeroescogido = true;
            }
        } while (numeroescogido == false);
        switch (numero) {
            case 1: {
                comidapoblacion = CrearComidaConstante();
                break;
            }
            case 2: {
                comidapoblacion = CrearComidaIncrementoLineal();
                break;
            }
            case 3: {
                comidapoblacion = CrearComidaIncrementoDecremento();
                break;
            }
            case 4: {
                comidapoblacion = CrearComidaIntermitente();
                break;
            }
        }
        Poblacionbacteria poblacion = null;
        boolean bacteriasnovalido;
        do {
            try {
                //numero de bacterias inicial
                System.out.println("Introduzca el numero de bacterias inicial");
                Scanner numerobacterias = new Scanner(System.in);
                numerobacteriasinicial = numerobacterias.nextInt();
                bacteriasnovalido = true;
            } catch (InputMismatchException excepcion) {
                System.out.println("Tiene que ser un numero entero");
                bacteriasnovalido = false;
            }
            try {
                poblacion = new Poblacionbacteria(nombre, comidapoblacion, numerobacteriasinicial, temperatura, luz);
                bacteriasnovalido = true;
            } catch (NumeroInicialBacteriasNoValidoException ex) {
                System.out.println("El numero inicial de bacterias no es valido");
                bacteriasnovalido = false;
            }
        } while (bacteriasnovalido == false);
        return poblacion;
    }

//Hacecmos un main de prueba en el que probamos las funciones. 
    //MAIN DE PRUEBA
    public static void main(String[] args) {
        Fecha fecha1 = CrearFecha();
        Poblacionbacteria poblacion1 = CrearPoblacion();
        String nombrepoblacion;
        System.out.println("Introduzca el nombre de la poblacion");
        Scanner nombre = new Scanner(System.in);
        nombrepoblacion = nombre.nextLine();
        System.out.println();
        System.out.println("Feca1   " + fecha1);
        for (int i = 0, j; i < 30; i++) {
            Boolean valido = false;

        }
    }
}
