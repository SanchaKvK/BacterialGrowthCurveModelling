/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inputOutput;

import excepciones.ExcepcionEstructuraIncorrecta;
import excepciones.Excepcioncomida;
import excepciones.Excepcionfecha;
import excepciones.MismaPoblacionException;
import excepciones.NoExistePoblacion;
import excepciones.NumeroInicialBacteriasNoValidoException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import static java.lang.System.exit;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import practica.Experimento;
import practica.Poblacionbacteria;
import static inputOutput.InputOutput.CrearPoblacion;
import static practica.AlgoritmosOrdenacion.OrdenacionPorBacteriasIniciales;
import static practica.AlgoritmosOrdenacion.OrdenacionPorFecha;
import static practica.AlgoritmosOrdenacion.OrdenacionPorNombre;
import static practica.FuncionesFichero.WriteExperimentToFile;
import static practica.FuncionesFichero.readExperimentFromFile;

/**
 * La clase Main del proyecto PRACTICA es la clase principal de la cual parte
 * el proyecto, consta de varias funciones que hacen uso de todas las clases
 * previas para poder realizar diferentes operaciones con la clase experimento.
 *
 * @author sanchavonknobloch
 */
public class Main {
    //Funcion visualizar nombres 

    /**
     * Funcion que imprime por pantalla nos nombres de las poblaciones de un
     * experimento que se le pasa como argumento.
     *
     * @param experimento el experimento del que se quieran imprimir sus nombres
     */
    public static void VisualizarNombresExperimento(Experimento experimento) {
        int opcion = 0;
        do {
            try {
                System.out.println("Desea visualizar los nombres de las poblaciones del experimento segun:");
                System.out.println("1) Orden alfabetico");
                System.out.println("2) Por fecha : desde la fecha de comienzo mas antigua hasta la mas reciente");
                System.out.println("3) Por numero de bacterias iniciales");
                Scanner s = new Scanner(System.in);
                opcion = s.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Debe ser un numero entero");
            }
        } while (opcion != 1 && opcion != 2 && opcion != 3);
        switch (opcion) {
            case 1: {
                OrdenacionPorNombre(experimento.getPoblacionesBacteria());
                break;
            }
            case 2: {
                OrdenacionPorFecha(experimento.getPoblacionesBacteria());

                break;
            }
            case 3: {
                OrdenacionPorBacteriasIniciales(experimento.getPoblacionesBacteria());
                break;
            }

        }
        for (String e : experimento.visualizarNombres()) {
            System.out.println(e);
        }
    }

    /**
     * la funcion GuardarComo sirve para guardar un experimento en un fichero,
     * ambos objetos pasados como argumento.
     *
     * @param experimento1 el experimento del que se quieren guardar sus
     * poblaciones
     * @param file1 la ruta del fichero en el cual se quiere guardar el
     * experimento
     */
    public static void GuardarComo(Experimento experimento1, File file1) {
        System.out.println("Introduzca el nombre del fichero en el que quiere guardar el experimento");
        Scanner nombre = new Scanner(System.in);
        String nombrefichero = nombre.nextLine();
        file1 = new File(nombrefichero);
        try {
            WriteExperimentToFile(file1, experimento1);
        } catch (IOException a) {
            System.out.println("no se ha podido guardar el experimento en el fichero");
        } catch (NullPointerException b) {
            System.out.println("No hay poblaciones que añadir");
        }
    }

    //FUNCION PARA COMENZAR A CREAR EXPERIMENTOS 
    /**
     * La funcion empezarExperimento() da al usuario la opcion de realizar una
     * serie de acciones(mediante un switch). La primera, abrir un fichero en el
     * que se haya guardado previamente un experimento, la segunda, crear un
     * nuevo experimento, la tercera, añadir una poblacion al experimento, la
     * cuarta visualizar los nombres de las poblaciones por pantalla, la quinta,
     * borrar una poblacion, la sexta, imprimir el contenido de una poblacion en
     * particular por pantalla, la septima es realizar una simulacion de
     * montecarlo con una poblacion especifica del experimento actual, la octava
     * guardar el experimento en un fichero y la novena es guardarlo dejando que
     * el usuario especifique la ruta.
     *
     */
    static public void empezarExperimento() {
        Experimento experimento1 = null;
        int opcion = 0;
        boolean numerovalido = true;
        File file1 = null;
        do {
            menu();
            Scanner opcionmenu = new Scanner(System.in);
            opcion = opcionmenu.nextInt();
            if (opcion < 1 || opcion > 10) {
                System.out.println("Las opciones validas abarcan desde el 1-8, si desea cerrar el programa pulse 0");
                opcion = opcionmenu.nextInt();
                if (opcion == 0) {
                    exit(0);
                }
            }
            switch (opcion) {
                case 1: {

                    System.out.println("Introduzca el nombre del fichero al que quiere acceder (ingresar ruta completa)");
                    Scanner nombre = new Scanner(System.in);
                    String nombrefichero = nombre.nextLine();
                    File filenuevo = new File(nombrefichero);
                    file1 = filenuevo;
                    try {
                        experimento1 = readExperimentFromFile(file1);
                    } catch (FileNotFoundException a) {
                        System.out.println("el fichero ingresado no se ha encontrado");
                        //ARREGLAR POBLACION MISMO NOMBRE
                    } catch (IOException b) {
                        System.out.println("Ha habido un problema con la lectura del archivo, por lo que sigue ingresado el experimento anterior, o ninguno en el caso de que no se haya hecho o ingresado uno previamente");
                    } catch (ExcepcionEstructuraIncorrecta c) {
                        System.out.println("Ha abierto un fichero que contiene informacion que es un experimento con poblaciones de bacterias");
                    } catch (MismaPoblacionException ex) {
                        Logger.getLogger(InputOutput.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (Excepcionfecha ex) {
                        Logger.getLogger(InputOutput.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (Excepcioncomida ex) {
                        Logger.getLogger(InputOutput.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (NumeroInicialBacteriasNoValidoException ex) {
                        Logger.getLogger(InputOutput.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    break;
                }
                case 2: {
                    //utilizamos el constructor que obliga al experimento a crear meter una poblacion de bacterias inicial
                    experimento1 = new Experimento(CrearPoblacion());
                    break;
                }
                case 3: {
                    if (experimento1 == null) {
                        System.out.println("Debe haber un experimento abierto para ingresar una poblacion");
                        break;
                    }
                    Poblacionbacteria poblacionañadir = CrearPoblacion();
                    try {
                        experimento1.añadirPoblacion(poblacionañadir);
                    } catch (MismaPoblacionException excepcion) {
                        System.out.println("La poblacion a añadir ya existe");
                    }
                    break;
                }
                case 4: {
                    try {
                        VisualizarNombresExperimento(experimento1);
                    } catch (NullPointerException excepcion) {
                        System.out.println("No se ha creado el experimento aun");
                    }
                    break;
                }
                case 5: {
                    System.out.println("NOMBRES DE LAS POBLACIONES DEL EXPERIMENTO");
                    try {
                        for (String e : experimento1.visualizarNombres()) {
                            System.out.println(e);
                        }
                        System.out.println("Introduzca el nombre de la poblacion "
                                + "de bacterias que desea eliminar");
                        Scanner nombrepoblacion = new Scanner(System.in);
                        String nombre = nombrepoblacion.nextLine();
                        try {
                            experimento1.borrarPoblacionBacteria(nombre);
                        } catch (NoExistePoblacion ex) {
                            System.out.println("No existe una poblacion con este nombre");
                        }
                    } catch (NullPointerException excepcion) {
                        System.out.println("No se ha creado el experimento aun");
                    } catch (InputMismatchException e) {
                        System.out.println("El nombre debe ser una cadena de caracteres");
                    }
                    break;
                }
                case 6: {
                    String nombrepoblacion;
                    Poblacionbacteria poblacionimprimir;
                    try {
                        System.out.println("Introduzca el nombre de la poblacion");
                        Scanner nombre = new Scanner(System.in);
                        nombrepoblacion = nombre.nextLine();
                        poblacionimprimir = experimento1.getPoblacionBacteria(nombrepoblacion);
                        System.out.println("El experimento tiene una poblacion de bacterias y es la siguiente: \n" + poblacionimprimir);
                        int valorescomida[] = poblacionimprimir.getComida().CantidadComidaCadaDia();
                        for (int i = 0; i < valorescomida.length; i++) {
                            System.out.println("La comida el dia" + (i + 1) + "es:   " + valorescomida[i]);
                        }
                    } catch (NullPointerException excepcion) {
                        System.out.println("No se ha creado el experimento aun");
                    } catch (InputMismatchException e) {
                        System.out.println("El nombre debe ser una cadena de caracteres");
                    } catch (NoExistePoblacion e) {
                        System.out.println("No existe una poblacion con este nombre");
                    }
                    break;
                }
                case 7: {
                    try {
                        String nombrepoblacion;
                        Poblacionbacteria poblacionimprimir;
                        System.out.println("Introduzca el nombre de la poblacion");
                        Scanner nombre = new Scanner(System.in);
                        nombrepoblacion = nombre.nextLine();
                        int bacteriascadadia[][][] = experimento1.getPoblacionBacteria(nombrepoblacion).Montecarlo();
                        System.out.println("HOLA"+bacteriascadadia.length);
                        for(int dia=0;dia<bacteriascadadia.length;dia++){
                            for(int fila=0;fila<20;fila++){
                                for(int columna=0;columna<20;columna++){
                                    System.out.println("El dia "+dia+1+"hay"+bacteriascadadia[dia][fila][columna]+"en la celda"+"["+fila+1+"]"+"["+columna+1+"]");
                                }
                            }
                        }
                        
                        //for (int i = 0; i < bacteriascadadia.length; i++) {
                           // System.out.println(bacteriascadadia[i]);
                        //}

                    } catch (NoExistePoblacion ex) {
                        System.out.println("No existe una poblacion con este nombre");
                    }catch(NullPointerException e){
                        System.out.println("Primero se debe abrir un experimento con poblaciones");
                    }
                    break;
                }
                case 8: {
                    if (experimento1 == null) {
                        System.out.println("Se debe tener un experimento abierto para guardar informacion");
                        break;
                    }
                    if (file1 != null) {
                        try {
                            WriteExperimentToFile(file1, experimento1);
                        } catch (IOException ex) {
                            System.out.println("ha ocurrido un error escribiendo en el archivo");
                        } catch (NullPointerException b) {
                            System.out.println("No hay poblaciones que añadir");
                        }
                    } else {
                        GuardarComo(experimento1, file1);
                    }

                    break;
                }
                case 9: {
                    GuardarComo(experimento1, file1);
                    break;
                }
                case 10: {
                    exit(0);
                }
            }
        } while (true);
    }

    /**
     * Funcion menu() imprime las opciones que hay para hacer en la practica.
     */
    static public void menu() {
        System.out.println("MENU \n");
        System.out.println("1.Abrir un archivo que contenga un experimento \n");
        System.out.println("2. Crear un nuevo experimento \n");
        System.out.println("3. Crear una población de bacterias y añadirla al experimento actual \n");
        System.out.println("4. Visualizar los nombres de todas las poblaciones de bacterias del experimento actual\n");
        System.out.println("5. Borrar una población de bacterias del experimento actual \n");
        System.out.println("6. Ver informacion detallada de una poblacion de bacterias del experimento actual \n");
        System.out.println("7. Realizar y visualizar la simulación correspondiente con una de las poblaciones\n"
                + "de bacterias del experimento \n");
        System.out.println("8. Guardar (se supone que para usar esta opción previamente hemos abierto un archivo \n");
        System.out.println("9. Guardar como \n");
        System.out.println("10. Cerrar programa");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        empezarExperimento();
    }
}
